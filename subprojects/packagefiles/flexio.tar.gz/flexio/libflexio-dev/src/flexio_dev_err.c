/*
 * SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "flexio_dev_int.h"
#include <libflexio-os/flexio_os.h>
#include <libflexio-os/flexio_os_mb.h>
#include <libflexio-dev/flexio_dev.h>
#include <libflexio-dev/flexio_dev_err.h>
#include <libflexio-os/flexio_os_syscall.h>
#include <libflexio-libc/string.h>

#include <libflexio-dev/flexio_dev_debug.h>

__attribute__((__noreturn__)) void flexio_dev_error(uint8_t error)
{
	if (!(error & 0x80)) {
		error = FLEXIO_DEV_ERROR_ILLEGAL_ERR;
	}

	flexio_dev_print("flexio_dev_error calling flexio_os_exit_process(0x%x)\n", error);
	print_sim_str("flexio_dev_error calling flexio_os_exit_process with ", 0);
	print_sim_hex(error, 0);
	print_sim_str("\n", 0);
	flexio_os_exit_process(error);
	flexio_dev_print("ERROR: flexio_dev_error should not be here\n");
	do {} while (1);
}

uint64_t flexio_dev_get_errno(struct flexio_dev_thread_ctx *dtctx)
{
	volatile struct flexio_os_thread_ctx *otctx = (void *)dtctx;

	RETURN_FAIL_IF_VALUE_IS_NULL(dtctx, UINT64_MAX);

	return otctx->flexio_os_errno;
}

void flexio_dev_rst_errno(struct flexio_dev_thread_ctx *dtctx)
{
	volatile struct flexio_os_thread_ctx *otctx = (void *)dtctx;

	RETURN_IF_VALUE_IS_NULL(dtctx);

	otctx->flexio_os_errno = FLEXIO_OS_ERRNO_OK;
}

uint64_t flexio_dev_get_and_rst_errno(struct flexio_dev_thread_ctx *dtctx)
{
	volatile struct flexio_os_thread_ctx *otctx = (void *)dtctx;

	RETURN_FAIL_IF_VALUE_IS_NULL(dtctx, UINT64_MAX);

	return __atomic_exchange_n(&otctx->flexio_os_errno, FLEXIO_OS_ERRNO_OK, __ATOMIC_SEQ_CST);
}
