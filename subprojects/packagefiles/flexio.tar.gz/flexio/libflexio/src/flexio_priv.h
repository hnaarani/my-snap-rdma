/*
 * SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __FLEXIO_PRIV_H__
#define __FLEXIO_PRIV_H__

#include "flexio_heap.h"
#include "flexio_exp.h"
#include "flexio_prm.h"
#include "uthash/uthash.h"

#include <common/flexio_common_defs.h>
#include <libflexio/flexio.h>
#include <pthread.h>
#include <sys/queue.h>

#define __unused __attribute__((unused))

#define LOG_NUM_HOST_SQ_DEPTH 1
#define LOG_SQ_STRIDE_BSIZE 6

#define FLEXIO_NOP_WQE_NUM_DS 0x1
#define FLEXIO_CTRL_SEND_RC_NUM_DS 0x2
#define FLEXIO_TRANSPOSE_WQE_NUM_DS 0x4

#define NUM_8BYTES_SEGS_IN_SWQE 8

#define LOG_FLEXIO_CQE_BSIZE 6
#define LOG_FLEXIO_RWQE_BSIZE 4
#define LOG_FLEXIO_SWQE_BSIZE 6
#define LOG_FLEXIO_CQ_BSIZE(log_q_depth) ((log_q_depth) + LOG_FLEXIO_CQE_BSIZE)
#define LOG_FLEXIO_RQ_BSIZE(log_q_depth) ((log_q_depth) + LOG_FLEXIO_RWQE_BSIZE)
#define LOG_FLEXIO_SQ_BSIZE(log_q_depth) ((log_q_depth) + LOG_SQ_STRIDE_BSIZE)

/* Convert logarithm to value */
#define L2V(l) (1UL << (l))
/* Convert logarithm to mask */
#define L2M(l) (L2V(l) - 1)
#define udma_to_device_barrier() do { asm volatile ("" ::: "memory"); } while (0)

#define EU_NUM(core_num, eu_num_in_core) ((core_num) * EUS_PER_CORE + eu_num_in_core)

struct flexio_alias {
	uint32_t id;
	struct mlx5dv_devx_obj *devx_obj;
};

struct flexio_host_cq {
	uint32_t eq_num;
	uint32_t cq_num;
	uint32_t cqe_index;
	uint32_t log_cq_depth;
	struct mlx5_cqe64 *cq_ring;
	uint32_t *cq_dbr;                       /* array of 2 be32 values */
	struct mlx5dv_devx_umem *cq_umem;
	struct mlx5dv_devx_umem *cq_dbr_umem;
	struct mlx5dv_devx_obj *devx_cq;
};

struct flexio_mkey {
	uint32_t id;
	struct mlx5dv_devx_obj *devx_obj;
	struct flexio_alias *alias_dumem;
};

struct flexio_uar {
	struct flexio_aliasable_obj aliasable;
	struct mlx5dv_devx_uar *devx_uar;
};

struct flexio_process_caps {
	uint32_t max_num_of_threads;
	uint32_t max_num_of_outboxes;
	uint32_t max_num_of_windows;
};

struct flexio_process_ref_count {
	uint32_t num_of_threads;
	uint32_t num_of_outboxes;
	uint32_t num_of_windows;
};

#define EXPOSE_DATA
struct flexio_process {
	/* NOTE - common part, exposed to NVIDIA users in file flexio_exp.h, should be placed on
	 * begin of full definition, defined in current file flexio_priv.h */
#undef __FLEXIO_EXP_H__
#define EXPOSE_PROCESS
#include "flexio_exp.h"
#undef EXPOSE_PROCESS

	struct flexio_prm_hca_caps *hca_caps;
	struct flexio_host_sq *ctrl_sq;
	struct flexio_mkey *internal_dumem_mkey;
	struct flexio_app *app;
	void *elf_buff;
	size_t elf_size;
	uint32_t current_thread_id;
	struct heap_ctx heap;
	int is_pcc;  /* PCC support indication */
	enum flexio_err_status dev_err_status;

	struct flexio_process_caps caps;
	struct flexio_process_ref_count ref_count;
	uint32_t destroy_pd;

	/* device messaging section */
	struct flexio_msg_stream *msg_stream_ctx[FLEXIO_MSG_DEV_MAX_STREAMS_AMOUNT];

	/* Error Handling */
	struct mlx5dv_devx_event_channel *event_channel;
};

struct flexio_host_qp {
	flexio_qp_state state;
	/* DevX resources */
	uint32_t qp_num;
	struct mlx5dv_devx_obj *devx_qp;
	struct ibv_context *ibv_ctx;

	/* config params */
	int log_rq_depth;
	int log_sq_depth;

	/* allocated memory */
	void *qp_wq_buffer_haddr;
	void *qp_sq_buffer_haddr;
	struct mlx5dv_devx_umem *qp_wq_buffer_umem;

	/* _rqd_ for Receive Queue Data */
	char *host_rqd_haddr; /* memory for received data */
	struct ibv_mr *host_rqd_mr;

	char *host_sqd_haddr; /* memory for send data */
	struct ibv_mr *host_sqd_mr;

	struct mlx5dv_devx_umem *qp_dbr_umem;

	pthread_mutex_t lock;
	/* start mutex protected */
	int wqe_counter;
	uint32_t sq_pi_index; /* sq producer index */
	uint32_t rq_pi_index; /* rq producer index */
	uint32_t *qp_dbr_haddr; /* array of 2 be32 values */
	__be32 *db;
	/* end mutex protected */
};

struct flexio_host_qp_attr {
	int log_wq_buffer_depth;
	int log_data_chunk_bsize;
	int is_rdma;

	uint32_t uar_id;
	uint32_t cq_num;
	uint32_t rq_type;
	uint32_t no_sq;

	struct ibv_pd *pd;
};

struct flexio_host_sq_attr {
	uint32_t cq_num;
	uint32_t user_index;
	uint8_t log_wqe_bsize;
	uint8_t log_num_entries;
};

struct flexio_transport_domain {
	uint32_t id;
	struct mlx5dv_devx_obj *obj;
};

struct flexio_host_sq {
	struct flexio_sq *flexio_sq;

	uint64_t *sq_buff;
	int log_sq_depth;
	struct flexio_host_cq *host_cq;

	struct flexio_cq *agent_cq;
	flexio_uintptr_t agent_cq_dbr_daddr;
	flexio_uintptr_t agent_cq_ring_daddr;

	struct mlx5dv_devx_umem *sq_umem;
	struct mlx5dv_devx_umem *sq_dbr_umem;

	pthread_mutex_t lock;
	/* start mutex protected */
	uint64_t *sq_dbr;
	uint32_t pi;
	int wqe_counter;
	__be32 *db;
	/* end mutex protected */
};

struct flexio_app {
	CIRCLEQ_ENTRY(flexio_app) node;
	char app_name[FLEXIO_MAX_NAME_LEN + 1];
	void *elf_buffer;
	size_t elf_size;
	uint32_t sig_exist;
	void *sig_buffer;
	size_t sig_size;
	struct flexio_func *func_list;

	pthread_mutex_t list_lock;
};

struct flexio_func {
	UT_hash_handle hh;
	struct flexio_app *app;
	uint32_t pup;
	flexio_func_t *host_stub_func_addr;
	size_t argbuf_size;
	flexio_func_arg_pack_fn_t *arg_pack_fn;
	flexio_uintptr_t dev_func_addr;
	flexio_uintptr_t dev_unpack_func_addr;
	char dev_func_name[FLEXIO_MAX_NAME_LEN + 1];
	char dev_unpack_func_name[FLEXIO_MAX_NAME_LEN + 1];
};

struct flexio_thread_attr {
	flexio_uintptr_t dev_func_addr;
	int continuable;
	uint64_t thread_arg;
	flexio_uintptr_t thread_local_storage_daddr;
	flexio_affinity affinity;
};

struct flexio_cmdq {
	struct flexio_process *process;
	struct flexio_uar *uar;
	struct flexio_window *window;
	struct ibv_mr *mr;

	/* data from host */
	struct flexio_cq *job_cq; /* triggers dispatcher with received jobs */
	struct flexio_qp *job_qp; /* dispatcher receive only */
	struct flexio_host_qp *host_qp; /* host send only */

	/* dispatcher-worker Communication */
	struct flexio_dev_async_rpc_worker_data *worker_data;
	struct flexio_qp **work2disp_qp;
	struct flexio_qp **disp2work_qp;
	struct flexio_cq **worker_cq; /* triggers worker thread with pending job */
	struct flexio_cq *cmpl_cq; /* triggers dispatcher with worker job completion */

	/* allocated dev memory */
	flexio_uintptr_t job_cq_dbr_daddr;
	flexio_uintptr_t job_cq_ring_daddr;
	flexio_uintptr_t cmpl_cq_dbr_daddr;
	flexio_uintptr_t cmpl_cq_ring_daddr;

	/* dev job qp */
	flexio_uintptr_t job_qp_dbr_daddr;
	flexio_uintptr_t job_qp_rq_ring_daddr;
	flexio_uintptr_t qp_rqd_daddr;
	struct flexio_mkey *job_qp_rqd_mkey;
	struct flexio_mkey *com_mkey;

	flexio_uintptr_t disp_data_daddr; /* dispatcher thread argument info */
	flexio_uintptr_t dpa_buf_daddr; /* dispatcher<->worker communication data buffers */
	flexio_uintptr_t workers_data_daddr; /* worker thread argument info */
	flexio_uintptr_t avail_workers_daddr; /* stack struct to hold free workers */
	flexio_uintptr_t batch_buf_daddr; /* local buffer to prepare job to send */

	struct flexio_event_handler *dispatcher;
	struct flexio_event_handler **workers;

	struct flexio_cmdq_attr attr;
	uint32_t *is_que_empty_haddr;
	int job_log_data_bsize;
};

/* Alias internal API */
int check_create_alias_dumem(struct flexio_process *process, struct ibv_context *ibv_ctx,
			     struct flexio_alias **dumem_alias, uint32_t *dumem_id);
int check_create_alias_thread(struct flexio_process *process, struct ibv_context *ibv_ctx,
			      struct flexio_aliasable_obj *orig_thread,
			      struct flexio_alias **thread_alias, uint32_t *thread_id);
struct flexio_alias *create_flexio_alias(struct ibv_context *orig_ctx, struct ibv_context *ctx,
					 uint32_t orig_vhca_id, struct flexio_aliasable_obj *obj);

/* CQ internal API */
struct mlx5_cqe64 *host_cq_get_cqe(struct flexio_host_cq *hcq);
int host_cq_create(struct ibv_context *ibv_ctx, int log_cq_depth,
		   struct mlx5dv_devx_uar *host_uar,
		   struct flexio_host_cq **hcq_ptr);
int host_cq_destroy(struct flexio_host_cq *hcq);
void cq_initial_arm(uint32_t cq_num, void *uar_base_addr);

/* Queue memory allocations */
flexio_uintptr_t qalloc_dbr(struct flexio_process *process);
flexio_uintptr_t qalloc_cq_ring(struct flexio_process *process, int log_depth);
int modify_dbr(struct flexio_process *process, flexio_uintptr_t dbr_daddr, uint32_t rcv_counter,
	       uint32_t send_counter);
/* Allocates buffer for QP queues (RQ and SQ), placed in one continuous buffer.
 * Allocated memory has not been initialized yet.
 * Return value - daddr of allocated continuous buffer.
 * RQ and SQ daddr - pointers to corresponding queues
 * if RQ or SQ not needed - suitable *daddr should be NULL */
flexio_uintptr_t qalloc_qp_wq_buff(struct flexio_process *process, int log_qp_rq_bsize,
				   flexio_uintptr_t *qp_rq_daddr, int log_qp_sq_bsize,
				   flexio_uintptr_t *qp_sq_daddr);

/* QP internal API */
int flexio_host_qp_create(struct ibv_pd *pd, struct ibv_context *ibv_ctx,
			  struct flexio_prm_hca_caps *hca_caps,
			  struct flexio_host_qp_attr *fattr, struct flexio_host_qp **host_qp_ptr);
int flexio_host_qp_destroy(struct flexio_host_qp *host_qp);
int flexio_host_qp_modify(struct flexio_host_qp *host_qp, struct flexio_qp_attr *fattr,
			  struct flexio_qp_attr_opt_param_mask *mask);

char *flexio_host_qp_wqe_data_get(struct flexio_host_qp *host_qp, uint32_t wqe_counter);
void host_qp_post_wqe(struct flexio_host_qp *host_qp, uint32_t opcode, uint32_t qp_buf_size,
		      void *buf, uint32_t buf_size);

/* SQ internal API */
int host_sq_create(struct flexio_process *process, struct flexio_host_sq_attr *host_sq_attr,
		   struct flexio_host_sq **host_sq_ptr);

int host_sq_destroy(struct flexio_host_sq *sq);
void host_sq_post_nop_wqe(struct flexio_host_sq *sq);
void host_sq_post_send(struct flexio_host_sq *sq, struct mlx5_wqe_ctrl_seg *ctrl_seg);

/* Thread internal API */
int create_thread(struct flexio_process *process, struct flexio_prm_thread_attr *prm_attr,
		  struct flexio_thread_attr *fattr, struct flexio_thread **thread);
flexio_thread_op_state thread_op_state_query(struct flexio_thread *thread);

/* ELF internal API */
int elf_get_sym_val(char *elf_buf, size_t buf_size, const char *sym_name, uint64_t *sym_val);
int elf_get_section_val(char *elf_buf, size_t buf_size, const char *sec_name, uint64_t *sec_off,
			uint64_t *sec_size);
int get_elf_file(const char *file_name, void **elf_buf, size_t *buf_size);

/* Service Helper Functions for internal usage only. */
void _align_host_umem_id_to_24b(struct mlx5dv_devx_umem *umem);
int _alloc_transport_domain(struct ibv_context *ibv_ctx, struct flexio_transport_domain **td);
int _dealloc_transport_domain(struct flexio_transport_domain *td);
uint32_t flexio_query_pdn(struct ibv_pd *pd);
int _error_event_register(struct flexio_process *process);

/* Application internal API */
int get_dev_func_data(struct flexio_app *app, flexio_func_t *host_func_addr,
		      struct flexio_func **func);

/* Thread internal API */
int thread_execute(struct flexio_process *process, struct flexio_thread_attr *fattr,
		   struct flexio_thread **thread);
int flexio_thread_destroy(struct flexio_thread *thread);

/* Process call internal API */
int non_packed_process_call(struct flexio_process *process, const char *dev_func_name, uint64_t arg,
			    struct flexio_affinity *affinity, uint64_t *func_ret);

/* @brief Create a DPA core dump with a configurable memory region size
 *
 * This function is exactly the same as flexio_coredump_create, except with an
 * additional argument to specify the memory region size used internally to
 * collect the core dump. This can be used for testing or if the default in the
 * public api function flexio_coredump_create is too small or too large
 */
flexio_status flexio_coredump_create_mrsize(struct flexio_process *process, const char *outfile,
					    uint32_t mr_size);
int dev_cq_mem_alloc(struct flexio_process *process, int log_cq_depth,
		     flexio_uintptr_t *cq_dbr_daddr_p, flexio_uintptr_t *cq_ring_daddr_p);
void flexio_mutex_init(pthread_mutex_t *lock);

#endif
