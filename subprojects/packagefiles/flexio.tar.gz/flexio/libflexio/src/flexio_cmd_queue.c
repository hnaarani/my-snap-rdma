/*
 * SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <malloc.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>

#include <common/flexio_common_defs.h>
#include <libflexio/flexio.h>
#include "flexio_log.h"
#include "flexio_prm.h"
#include "flexio_priv.h"
#include "ccan/ilog/ilog.h"

#define FLEXIO_HW_ASYNC_RPC_DISPATCHER_FUNC_NAME "flexio_hw_async_rpc_dispatcher"
#define FLEXIO_HW_ASYNC_RPC_WORKER_FUNC_NAME "flexio_hw_async_rpc_worker"
#define CMDQ_WORK2DISP_LOG_DATA_CHUNK_BSIZE 3
#define CMDQ_WORK2DISP_BUF_SIZE L2V(CMDQ_WORK2DISP_LOG_DATA_CHUNK_BSIZE)

static int cmd_queue_dev_qp_init(struct flexio_process *process,
				 struct flexio_qp_attr *fattr,
				 uint32_t log_qpd_bsize,
				 flexio_uintptr_t *qp_rq_ring,
				 flexio_uintptr_t *qp_sq_ring,
				 flexio_uintptr_t *qp_rqd_daddr,
				 flexio_uintptr_t *qp_sqd_daddr,
				 struct flexio_mkey **rqd_mkey,
				 struct flexio_mkey **sqd_mkey,
				 int is_alloc_data_buf)
{
	struct mlx5_wqe_data_seg *dseg, *rx_wqes = NULL;
	struct flexio_mkey_attr mkey_attr = {0};
	int log_rq_ring_depth = 0;
	int log_sq_ring_depth = 0;
	size_t data_chunk_bsize;
	uint32_t ring_bsize;
	int num_of_wqes = 0;
	int data_bsize;
	int i, err;

	/* allocate data buffers */
	if (fattr->rq_type != MLX5_QPC_RQ_TYPE_ZERO_SIZE_RQ) {
		log_rq_ring_depth = LOG_FLEXIO_RQ_BSIZE(fattr->log_rq_depth);

		if (is_alloc_data_buf) {
			data_bsize = L2V(fattr->log_rq_depth + log_qpd_bsize);
			flexio_buf_dev_alloc(process, data_bsize, qp_rqd_daddr);
			if (!qp_rqd_daddr) {
				flexio_err("Cmd-q: Failed to allocate dev RQ data buffer\n");
				goto err_out;
			}

			mkey_attr.access = fattr->qp_access_mask;
			mkey_attr.pd = process->internal_pd;
			mkey_attr.daddr = *qp_rqd_daddr;
			mkey_attr.len = data_bsize;
			err = flexio_device_mkey_create(process, &mkey_attr, rqd_mkey);
			if (err) {
				flexio_err("Cmd-q: Failed to create RQ data buffer MKey (err %#x\n",
					   err);
				goto err_out;
			}
		}
	}
	if (!fattr->no_sq) {
		log_sq_ring_depth = LOG_FLEXIO_SQ_BSIZE(fattr->log_sq_depth);

		if (is_alloc_data_buf) {
			data_bsize = L2V(fattr->log_sq_depth + log_qpd_bsize);
			flexio_buf_dev_alloc(process, data_bsize, qp_sqd_daddr);
			if (!qp_sqd_daddr) {
				flexio_err("Cmd-q: Failed to allocate dev SQ data buffer\n");
				goto err_out;
			}

			mkey_attr.access = fattr->qp_access_mask;
			mkey_attr.pd = process->internal_pd;
			mkey_attr.daddr = *qp_sqd_daddr;
			mkey_attr.len = data_bsize;
			err = flexio_device_mkey_create(process, &mkey_attr, sqd_mkey);
			if (err) {
				flexio_err("Cmd-q: Failed to create SQ data buffer MKey (err %#x\n",
					   err);
				goto err_out;
			}
		}
	}

	/* allocate rings */
	fattr->qp_wq_buff_qmem.memtype = FLEXIO_MEMTYPE_DPA;
	fattr->qp_wq_buff_qmem.daddr = qalloc_qp_wq_buff(process, log_rq_ring_depth, qp_rq_ring,
							 log_sq_ring_depth, qp_sq_ring);
	if (!fattr->qp_wq_buff_qmem.daddr) {
		flexio_err("Cmd-q: failed to allocate DEV QP rings");
		goto err_out;
	}

	/* init rq ring */
	if (fattr->rq_type != MLX5_QPC_RQ_TYPE_ZERO_SIZE_RQ) {
		num_of_wqes = L2V(fattr->log_rq_depth);
		ring_bsize = L2V(log_rq_ring_depth);
		data_chunk_bsize = L2V(log_qpd_bsize);

		rx_wqes = calloc(num_of_wqes, sizeof(struct mlx5_wqe_data_seg));
		assert(rx_wqes);

		/* Initialize WQEs' data segment */
		dseg = rx_wqes;

		for (i = 0; i < num_of_wqes; i++) {
			mlx5dv_set_data_seg(dseg, data_chunk_bsize, (*rqd_mkey)->id,
					    *qp_rqd_daddr + i * data_chunk_bsize);
			dseg++;
		}

		/* Copy RX WQEs from host to Flex IO RQ ring */
		if (flexio_host2dev_memcpy(process, rx_wqes, ring_bsize, *qp_rq_ring)) {
			flexio_err("Cmd-q: Failed to copy rq ring to dev\n");
			goto err_out;
		}

		free(rx_wqes);
		rx_wqes = NULL;
	}

	/* DBR */
	fattr->qp_wq_buff_qmem.memtype = FLEXIO_MEMTYPE_DPA;
	fattr->qp_wq_dbr_qmem.daddr = qalloc_dbr(process);
	if (!fattr->qp_wq_dbr_qmem.daddr) {
		flexio_err("Cmd-q: failed to allocate DEV QP DBR");
		goto err_out;
	}

	return 0;

err_out:
	if (rqd_mkey)
		flexio_device_mkey_destroy(*rqd_mkey);
	if (sqd_mkey)
		flexio_device_mkey_destroy(*sqd_mkey);
	if (is_alloc_data_buf) {
		if (qp_rqd_daddr) {
			flexio_buf_dev_free(process, *qp_rqd_daddr);
			*qp_rqd_daddr = 0;
		}
		if (qp_sqd_daddr) {
			flexio_buf_dev_free(process, *qp_sqd_daddr);
			*qp_sqd_daddr = 0;
		}
	}
	flexio_buf_dev_free(process, fattr->qp_wq_buff_qmem.daddr);
	flexio_buf_dev_free(process, fattr->qp_wq_dbr_qmem.daddr);
	free(rx_wqes);
	fattr->qp_wq_buff_qmem.daddr = 0;
	fattr->qp_wq_dbr_qmem.daddr = 0;

	return -1;
}

flexio_status flexio_cmdq_create(struct flexio_process *process, struct flexio_cmdq_attr *fattr,
				 struct flexio_cmdq **cmdq)
{
	struct flexio_qp_attr_opt_param_mask qp_fattr_opt_param_mask = {0};
	struct flexio_qp_attr dev_qp_attr = {0}, host_qp_modify_attr = {0};
	struct flexio_event_handler_attr event_handler_attr = {0};
	struct flexio_dev_async_rpc_data async_rpc_data = {0};
	int size, log_que_depth, log_disp2work_data_bsize;
	struct flexio_dev_async_rpc_worker_data *worker;
	struct flexio_host_qp_attr host_qp_attr = {0};
	struct flexio_cq_attr dev_cq_attr = {0};
	struct flexio_mkey_attr mkey_attr = {0};
	flexio_uintptr_t worker_daddr;
	flexio_func_t *dev_func_stub;
	struct flexio_cmdq* q;
	int i, retval;

	/* validations */

	if (!cmdq) {
		flexio_err("Cmd-q: illegal cmdq argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	*cmdq = NULL;

	if (!process) {
		flexio_err("Cmd-q: illegal process argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!fattr) {
		flexio_err("Cmd-q: illegal attr argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!fattr->workers ||
	    fattr->workers > (int)L2V(process->hca_caps->log_max_dpa_threads_per_process))
	{
		flexio_err("Cmd-q: illegal attr workers argument: %u\n", fattr->workers);
		return -FLEXIO_STATUS_FAILED;
	}

	if (!fattr->batch_size) {
		flexio_err("Cmd-q: illegal attr batch_size: %u\n", fattr->batch_size);
		return -FLEXIO_STATUS_FAILED;
	}

	if (fattr->state != FLEXIO_CMDQ_STATE_PENDING &&
	    fattr->state != FLEXIO_CMDQ_STATE_RUNNING)
	{
		flexio_err("Cmd-q: illegal attr state argument: %u\n", fattr->state);
		return -FLEXIO_STATUS_FAILED;
	}

	/* Context */
	q = calloc(1, sizeof(struct flexio_cmdq));
	assert(q);
	q->process = process;
	q->attr = *fattr;
	pthread_mutex_init(&q->task_add_mtx, NULL);
	q->job_log_data_bsize = ilog32(sizeof(struct flexio_dev_async_rpc_worker_param));

	assert(posix_memalign((void**)&q->is_que_empty_haddr, 64, 64) == 0);
	assert(q->is_que_empty_haddr);
	*q->is_que_empty_haddr = 1;
	q->mr = ibv_reg_mr(process->internal_pd, q->is_que_empty_haddr, 64,
			   IBV_ACCESS_LOCAL_WRITE);
	if (!q->mr) {
		flexio_err("Cmd-q:Failed to reg MR");
		goto err_out;
	}
	if (flexio_window_create(process, process->internal_pd, &q->window)) {
		flexio_err("Cmd-q: Failed to create window");
		goto err_out;
	}

	size = fattr->workers * fattr->batch_size;
	log_que_depth = ilog32(size);
	async_rpc_data.num_workers = fattr->workers;
	async_rpc_data.batch = fattr->batch_size;
	async_rpc_data.que_depth_mask = L2M(log_que_depth);
	async_rpc_data.is_que_empty_haddr = (uint64_t)q->is_que_empty_haddr;
	async_rpc_data.window_id = q->window->window_id;
	async_rpc_data.mr_lkey = q->mr->lkey;

	if (flexio_uar_create(process, process->host_uar, &q->uar)) {
		flexio_err("Cmd-q: Failed to create Flex IO UAR\n");
		goto err_out;
	}

	if (flexio_outbox_create(process, NULL, q->uar, &q->outbox) != FLEXIO_STATUS_SUCCESS) {
		flexio_err("Cmd-q: Failed to create Flex IO outbox\n");
		goto err_out;
	}

	if (flexio_func_register(process->app, FLEXIO_HW_ASYNC_RPC_DISPATCHER_FUNC_NAME,
				 &dev_func_stub) != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: dispatcher flexio_func_register failed\n");
		goto err_out;
	}

	/* Create dispatcher */
	event_handler_attr.host_stub_func = dev_func_stub;
	event_handler_attr.arg = 0;
	event_handler_attr.affinity.type = FLEXIO_AFFINITY_NONE;
	if (flexio_event_handler_create(process, &event_handler_attr, q->outbox,
					&q->dispatcher) != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: Flexio dispatcher event handler create failed\n");
		goto err_out;
	}

	/* cq depth should be enough for batch_size per worker.
	 * This cq is used to receive host jobs by dispatcher. */
	dev_cq_attr.log_cq_depth = log_que_depth;
	dev_cq_attr.element_type = FLEXIO_CQ_ELEMENT_TYPE_DPA_THREAD;
	dev_cq_attr.thread = flexio_event_handler_get_thread(q->dispatcher);
	dev_cq_attr.uar_id = process->host_uar->page_id;
	dev_cq_attr.uar_base_addr = process->host_uar->base_addr;
	q->job_cq_dbr_daddr = qalloc_dbr(process);
	q->job_cq_ring_daddr = qalloc_cq_ring(process, dev_cq_attr.log_cq_depth);
	if (!q->job_cq_dbr_daddr || !q->job_cq_ring_daddr) {
		flexio_err("Cmd-q: Failed to allocate memory for job-CQ\n");
		goto err_out;
	}
	dev_cq_attr.cq_dbr_daddr = q->job_cq_dbr_daddr;
	dev_cq_attr.cq_ring_qmem.memtype = FLEXIO_MEMTYPE_DPA;
	dev_cq_attr.cq_ring_qmem.daddr = q->job_cq_ring_daddr;
	dev_cq_attr.no_arm = fattr->state == FLEXIO_CMDQ_STATE_PENDING;
	if (flexio_cq_create(process, process->ibv_ctx, &dev_cq_attr, &q->job_cq)
	    != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: Flexio device dispatcher job-CQ create failed\n");
		goto err_out;
	}
	flexio_print(FLEXIO_LOG_LVL_DBG, "Cmd-q: job cq_num %#x depth %lu", q->job_cq->cq_num,
		     L2V(log_que_depth));
	async_rpc_data.job_cq.q_num = q->job_cq->cq_num;
	async_rpc_data.job_cq.dbr_daddr = q->job_cq_dbr_daddr;
	async_rpc_data.job_cq.cq_ring_daddr = q->job_cq_ring_daddr;
	async_rpc_data.job_cq.cap_cqe_version = process->hca_caps->cqe_version;

	/* send host messages to dispatcher */
	host_qp_attr.log_wq_buffer_depth = log_que_depth;
	host_qp_attr.log_data_chunk_bsize = q->job_log_data_bsize;
	host_qp_attr.uar_id = process->host_uar->page_id;
	host_qp_attr.cq_num = q->job_cq->cq_num;
	host_qp_attr.is_rdma = 0;
	host_qp_attr.pd = process->internal_pd;
	host_qp_attr.no_sq = 0;
	host_qp_attr.rq_type = MLX5_QPC_RQ_TYPE_ZERO_SIZE_RQ;

	if (flexio_host_qp_create(process->internal_pd, process->ibv_ctx, process->hca_caps,
				  &host_qp_attr, &q->host_qp))
	{
		flexio_err("Cmd-q: failed to create HOST QP");
		goto err_out;
	}
	q->host_qp->db = (__be32 *)process->host_uar->reg_addr;
	flexio_print(FLEXIO_LOG_LVL_DBG, "Cmd-q: HOST qp_num %#x", q->host_qp->qp_num);

	/* receive messages from host - device QP jobs */
	dev_qp_attr.transport_type = FLEXIO_QPC_ST_RC;
	dev_qp_attr.rq_type = MLX5_QPC_RQ_TYPE_REGULAR;
	dev_qp_attr.log_rq_depth = log_que_depth;
	dev_qp_attr.no_sq = 1;
	dev_qp_attr.log_sq_depth = 0;
	dev_qp_attr.sq_cqn = q->job_cq->cq_num;
	dev_qp_attr.rq_cqn = q->job_cq->cq_num;
	dev_qp_attr.uar_id = q->uar->aliasable.id;
	dev_qp_attr.pd = process->internal_pd;
	dev_qp_attr.qp_access_mask = IBV_ACCESS_LOCAL_WRITE;
	retval = cmd_queue_dev_qp_init(process, &dev_qp_attr, q->job_log_data_bsize,
				       &q->job_qp_rq_ring_daddr, NULL, &q->qp_rqd_daddr, NULL,
				       &q->job_qp_rqd_mkey, NULL, 1);
	if (retval)
		goto err_out;

	if (flexio_qp_create(process, process->ibv_ctx, &dev_qp_attr, &q->job_qp)
	    != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: failed to create DEV QP");
		goto err_out;
	}

	if (modify_dbr(process, dev_qp_attr.qp_wq_dbr_qmem.daddr, L2V(dev_qp_attr.log_rq_depth), 0))
	{
		flexio_err("Cmd-q: failed to init DEV QP DBR");
		goto err_out;
	}

	flexio_print(FLEXIO_LOG_LVL_DBG, "Cmd-q: DEV job qp_num %#x", q->job_qp->qp_num);
	q->job_qp_dbr_daddr = dev_qp_attr.qp_wq_dbr_qmem.daddr;
	async_rpc_data.job_qp.q_num = q->job_qp->qp_num;
	async_rpc_data.job_qp.dbr_daddr = dev_qp_attr.qp_wq_dbr_qmem.daddr;
	async_rpc_data.job_qp.qp_wq_rq_daddr = q->job_qp_rq_ring_daddr;

	/* connect qp dev and qp host */
	host_qp_modify_attr.remote_qp_num = q->job_qp->qp_num;
	host_qp_modify_attr.qp_access_mask = IBV_ACCESS_LOCAL_WRITE;
	host_qp_modify_attr.fl = 1; /* force loop-back is ON */
	host_qp_modify_attr.min_rnr_nak_timer = 0x12;
	host_qp_modify_attr.path_mtu = FLEXIO_QP_QPC_MTU_BYTES_1K;
	host_qp_modify_attr.vhca_port_num = 0x1;
	host_qp_modify_attr.next_state = FLEXIO_QP_STATE_INIT;
	/* Host QP transition - RST2INIT */
	if (flexio_host_qp_modify(q->host_qp, &host_qp_modify_attr, &qp_fattr_opt_param_mask)) {
		flexio_err("Cmd-q: failed to transition Host QP from RST to INIT");
		goto err_out;
	}

	host_qp_modify_attr.next_state = FLEXIO_QP_STATE_RTR;
	/* Host QP transition - INIT2RTR */
	if (flexio_host_qp_modify(q->host_qp, &host_qp_modify_attr, &qp_fattr_opt_param_mask)) {
		flexio_err("Cmd-q: failed to transition Host QP from INIT to RTR");
		goto err_out;
	}

	host_qp_modify_attr.next_state = FLEXIO_QP_STATE_RTS;
	/* Host QP transition - RTR2RTS */
	if (flexio_host_qp_modify(q->host_qp, &host_qp_modify_attr, &qp_fattr_opt_param_mask)) {
		flexio_err("Cmd-q: failed to transition Host QP from RTR to RTS");
		goto err_out;
	}

	/* dispatcher QP */
	dev_qp_attr.remote_qp_num = q->host_qp->qp_num;
	dev_qp_attr.fl = 1;
	dev_qp_attr.min_rnr_nak_timer = 0x12;
	dev_qp_attr.path_mtu = FLEXIO_QP_QPC_MTU_BYTES_1K;
	dev_qp_attr.retry_count = 0x7;
	dev_qp_attr.vhca_port_num = 0x1;
	dev_qp_attr.next_state = FLEXIO_QP_STATE_INIT;
	dev_qp_attr.qp_access_mask = IBV_ACCESS_LOCAL_WRITE;
	/* FlexIO QP transition - RST2INIT */
	if (flexio_qp_modify(q->job_qp, &dev_qp_attr, &qp_fattr_opt_param_mask)
	    != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: failed to transition Flex IO dev QP from RST to INIT");
		goto err_out;
	}

	dev_qp_attr.next_state = FLEXIO_QP_STATE_RTR;
	/* FlexIO QP transition - INIT2RTR */
	if (flexio_qp_modify(q->job_qp, &dev_qp_attr, &qp_fattr_opt_param_mask)
	    != FLEXIO_STATUS_SUCCESS) {
		flexio_err("Cmd-q: failed to transition Flex IO dev QP from INIT to RTR");
		goto err_out;
	}

	dev_qp_attr.next_state = FLEXIO_QP_STATE_RTS;
	/* FlexIO QP transition - RTR2RTS */
	if (flexio_qp_modify(q->job_qp, &dev_qp_attr, &qp_fattr_opt_param_mask)
	    != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: failed to transition Flex IO dev QP from RTR to RTS");
		goto err_out;
	}

	/* create completion CQ to receive worker job completion message */
	dev_cq_attr.log_cq_depth = log_que_depth;
	dev_cq_attr.element_type = FLEXIO_CQ_ELEMENT_TYPE_DPA_THREAD;
	dev_cq_attr.thread = flexio_event_handler_get_thread(q->dispatcher);
	dev_cq_attr.uar_id = process->host_uar->page_id;
	dev_cq_attr.uar_base_addr = process->host_uar->base_addr;
	q->cmpl_cq_dbr_daddr = qalloc_dbr(process);
	q->cmpl_cq_ring_daddr = qalloc_cq_ring(process, dev_cq_attr.log_cq_depth);
	if (!q->cmpl_cq_dbr_daddr || !q->cmpl_cq_ring_daddr) {
		flexio_err("Cmd-q: Failed to allocate memory for completion CQ\n");
		goto err_out;
	}
	dev_cq_attr.cq_ring_qmem.memtype = FLEXIO_MEMTYPE_DPA;
	dev_cq_attr.cq_ring_qmem.daddr = q->cmpl_cq_ring_daddr;
	dev_cq_attr.cq_dbr_daddr = q->cmpl_cq_dbr_daddr;
	dev_cq_attr.no_arm = 0;
	if (flexio_cq_create(process, process->ibv_ctx, &dev_cq_attr, &q->cmpl_cq)
	    != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: Flexio device completion CQ create failed\n");
		goto err_out;
	}
	flexio_print(FLEXIO_LOG_LVL_DBG, "Cmd-q: DEV work complete cq_num %#x",
		     q->cmpl_cq->cq_num);
	async_rpc_data.cmpl_cq.q_num =  q->cmpl_cq->cq_num;
	async_rpc_data.cmpl_cq.dbr_daddr = q->cmpl_cq_dbr_daddr;
	async_rpc_data.cmpl_cq.cq_ring_daddr = q->cmpl_cq_ring_daddr;
	async_rpc_data.cmpl_cq.cap_cqe_version = process->hca_caps->cqe_version;

	/* allocate infrastructure */
	q->workers = calloc(fattr->workers, sizeof(struct flexio_event_handler *));
	assert(q->workers);
	q->worker_data = calloc(fattr->workers, sizeof(struct flexio_dev_async_rpc_worker_data));
	assert(q->worker_data);
	q->work2disp_qp = calloc(fattr->workers, sizeof(struct flexio_qp *));
	assert(q->work2disp_qp);
	q->disp2work_qp = calloc(fattr->workers, sizeof(struct flexio_qp *));
	assert(q->disp2work_qp);
	q->worker_cq = calloc(fattr->workers, sizeof(struct flexio_cq *));
	assert(q->worker_cq);

	if (flexio_buf_dev_alloc(process,
				 (fattr->workers *
				 sizeof(struct flexio_dev_async_rpc_worker_data)),
				 &q->workers_data_daddr) != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: Failed to allocate Flex IO memory");
		goto err_out;
	}
	async_rpc_data.workers_data_daddr = q->workers_data_daddr;

	/* Allocate single chunk of device memory for all worker<->dispatcher QPs
	 * send and receive data buffers. */
	size = CMDQ_DISP2WORK_BUF_BSIZE(fattr->batch_size);
	log_disp2work_data_bsize = ilog32(size);
	/* memory required for 1 worker<->dispatcher communication (2 QPs) */
	size = (L2V(log_disp2work_data_bsize) + L2V(CMDQ_WORK2DISP_LOG_DATA_CHUNK_BSIZE)) *
	       (L2V(CMDQ_LOG_DEV_WORKER_QP_SEND_RINGS_DEPTH) +
		L2V(CMDQ_LOG_DEV_WORKER_QP_RECV_RINGS_DEPTH));
	/* round up to 64 bytes */
	if (size & 0x3f)
		size = ((size >> 6) + 1) << 6;
	mkey_attr.len = (size_t)size * q->attr.workers;
	if (flexio_buf_dev_alloc(process, mkey_attr.len, &q->dpa_buf_daddr)
	    != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: Failed to allocate Flex IO memory");
		goto err_out;
	}
	mkey_attr.pd = process->internal_pd;
	mkey_attr.daddr = q->dpa_buf_daddr;
	mkey_attr.access = IBV_ACCESS_LOCAL_WRITE;
	if (flexio_device_mkey_create(process, &mkey_attr, &q->com_mkey) != FLEXIO_STATUS_SUCCESS) {
		flexio_err("Cmd-q: Failed to create QPs memory MKey\n");
		goto err_out;
	}

	if (flexio_func_register(process->app, FLEXIO_HW_ASYNC_RPC_WORKER_FUNC_NAME,
				 &dev_func_stub) != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: worker flexio_func_register failed\n");
		goto err_out;
	}

	event_handler_attr.host_stub_func = dev_func_stub;
	event_handler_attr.arg = 0;
	event_handler_attr.affinity.type = FLEXIO_AFFINITY_NONE;
	/* create worker CQ and dispatcher <-> worker communication QPs */
	for (i = 0; i < fattr->workers; i++) {
		worker = &q->worker_data[i];
		if (flexio_event_handler_create(process, &event_handler_attr, q->outbox,
						&(q->workers[i])) != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Cmd-q: Failed to create worker event handlers");
			goto err_out;
		}
		worker->worker_id = i;
		worker->dev_lkey = q->com_mkey->id;
		worker->work2disp_qp.qp_rqd_daddr = q->dpa_buf_daddr + i * size;
		worker->work2disp_qp.qp_sqd_daddr = worker->work2disp_qp.qp_rqd_daddr +
						    CMDQ_WORK2DISP_BUF_SIZE *
						    L2V(CMDQ_LOG_DEV_WORKER_QP_RECV_RINGS_DEPTH);
		worker->disp2work_qp.qp_rqd_daddr = worker->work2disp_qp.qp_sqd_daddr +
						    CMDQ_WORK2DISP_BUF_SIZE *
						    L2V(CMDQ_LOG_DEV_WORKER_QP_SEND_RINGS_DEPTH);
		worker->disp2work_qp.qp_sqd_daddr = worker->disp2work_qp.qp_rqd_daddr +
						    L2V(log_disp2work_data_bsize) *
						    L2V(CMDQ_LOG_DEV_WORKER_QP_RECV_RINGS_DEPTH);

		/* worker receive job cq */
		dev_cq_attr.log_cq_depth = CMDQ_LOG_DEV_WORKER_CQ_RING_DEPTH;
		dev_cq_attr.element_type = FLEXIO_CQ_ELEMENT_TYPE_DPA_THREAD;
		dev_cq_attr.thread = flexio_event_handler_get_thread(q->workers[i]);
		dev_cq_attr.uar_id = process->host_uar->page_id;
		dev_cq_attr.uar_base_addr = q->uar->devx_uar->base_addr;
		worker->worker_cq.dbr_daddr = qalloc_dbr(process);
		worker->worker_cq.cq_ring_daddr = qalloc_cq_ring(process, dev_cq_attr.log_cq_depth);
		if (!worker->worker_cq.dbr_daddr || !worker->worker_cq.cq_ring_daddr) {
			flexio_err("Cmd-q: Failed to allocate memory for worker %u CQ\n", i);
			goto err_out;
		}
		dev_cq_attr.cq_ring_qmem.memtype = FLEXIO_MEMTYPE_DPA;
		dev_cq_attr.cq_ring_qmem.daddr = worker->worker_cq.cq_ring_daddr;
		dev_cq_attr.cq_dbr_daddr = worker->worker_cq.dbr_daddr;
		dev_cq_attr.no_arm = 0;
		if (flexio_cq_create(process, process->ibv_ctx, &dev_cq_attr, &q->worker_cq[i])
		    != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Flexio device worker CQ %u create failed\n", i);
			goto err_out;
		}
		worker->worker_cq.q_num = q->worker_cq[i]->cq_num;
		worker->worker_cq.cap_cqe_version = process->hca_caps->cqe_version;
		flexio_print(FLEXIO_LOG_LVL_DBG, "Cmd-q: worker %u cq_num %#x", i,
			     q->worker_cq[i]->cq_num);

		/* create device QP - dispatcher to worker job messages */
		dev_qp_attr.transport_type = FLEXIO_QPC_ST_RC;
		dev_qp_attr.rq_type = MLX5_QPC_RQ_TYPE_REGULAR;
		dev_qp_attr.no_sq = 0;
		dev_qp_attr.log_sq_depth = CMDQ_LOG_DEV_WORKER_QP_SEND_RINGS_DEPTH;
		dev_qp_attr.log_rq_depth = CMDQ_LOG_DEV_WORKER_QP_RECV_RINGS_DEPTH;
		dev_qp_attr.sq_cqn = worker->worker_cq.q_num;
		dev_qp_attr.rq_cqn = worker->worker_cq.q_num;
		dev_qp_attr.uar_id = process->host_uar->page_id;
		dev_qp_attr.pd = process->internal_pd;
		dev_qp_attr.qp_access_mask = IBV_ACCESS_LOCAL_WRITE;
		retval = cmd_queue_dev_qp_init(process, &dev_qp_attr, log_disp2work_data_bsize,
					       &worker->disp2work_qp.qp_wq_rq_daddr,
					       &worker->disp2work_qp.qp_wq_sq_daddr,
					       &worker->disp2work_qp.qp_rqd_daddr,
					       &worker->disp2work_qp.qp_sqd_daddr,
					       &q->com_mkey, NULL, 0);
		if (retval)
			goto err_out;
		if (flexio_qp_create(process, process->ibv_ctx, &dev_qp_attr,
				     &q->disp2work_qp[i]) != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Cmd-q: Flex IO worker %u dispatcher to worker QP create failed",
				   i);
			goto err_out;
		}

		if (modify_dbr(process, dev_qp_attr.qp_wq_dbr_qmem.daddr,
				 L2V(dev_qp_attr.log_rq_depth), 0))
		{
			flexio_err("Cmd-q: failed to init DEV QP DBR");
			goto err_out;
		}

		flexio_print(FLEXIO_LOG_LVL_DBG, "Cmd-q: DEV dispatcher to worker %u qp_num %#x",
			     i, q->disp2work_qp[i]->qp_num);
		worker->disp2work_qp.q_num = q-> disp2work_qp[i]->qp_num;
		worker->disp2work_qp.dbr_daddr = dev_qp_attr.qp_wq_dbr_qmem.daddr;

		/* FlexIO QP transition - RST2INIT */
		dev_qp_attr.remote_qp_num = worker->disp2work_qp.q_num;
		dev_qp_attr.fl = 1;
		dev_qp_attr.min_rnr_nak_timer = 0x12;
		dev_qp_attr.path_mtu = FLEXIO_QP_QPC_MTU_BYTES_1K;
		dev_qp_attr.retry_count = 0x7;
		dev_qp_attr.vhca_port_num = 0x1;
		dev_qp_attr.next_state = FLEXIO_QP_STATE_INIT;
		if (flexio_qp_modify(q->disp2work_qp[i], &dev_qp_attr, &qp_fattr_opt_param_mask)
		    != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Cmd-q: failed to modify worker %u QP from RST to INIT", i);
			goto err_out;
		}

		/* FlexIO QP transition - INIT2RTR */
		dev_qp_attr.next_state = FLEXIO_QP_STATE_RTR;
		if (flexio_qp_modify(q->disp2work_qp[i], &dev_qp_attr, &qp_fattr_opt_param_mask)
		    != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Cmd-q: failed to modify worker %u QP from INIT to RTR", i);
			goto err_out;
		}

		/* FlexIO QP transition - RTR2RTS */
		dev_qp_attr.next_state = FLEXIO_QP_STATE_RTS;
		if (flexio_qp_modify(q->disp2work_qp[i], &dev_qp_attr, &qp_fattr_opt_param_mask)
		    != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Cmd-q: failed to modify worker %u QP from RTR to RTS", i);
			goto err_out;
		}

		/* create device QP - worker to dispatcher job completion messages */
		dev_qp_attr.transport_type = FLEXIO_QPC_ST_RC;
		dev_qp_attr.rq_type = MLX5_QPC_RQ_TYPE_REGULAR;
		dev_qp_attr.no_sq = 0;
		dev_qp_attr.log_sq_depth = CMDQ_LOG_DEV_WORKER_QP_SEND_RINGS_DEPTH;
		dev_qp_attr.log_rq_depth = CMDQ_LOG_DEV_WORKER_QP_RECV_RINGS_DEPTH;
		dev_qp_attr.sq_cqn = q->cmpl_cq->cq_num;
		dev_qp_attr.rq_cqn = q->cmpl_cq->cq_num;
		dev_qp_attr.user_index = i;
		dev_qp_attr.uar_id = q->uar->devx_uar->page_id;
		dev_qp_attr.pd = process->internal_pd;
		dev_qp_attr.qp_access_mask = IBV_ACCESS_LOCAL_WRITE;
		retval = cmd_queue_dev_qp_init(process, &dev_qp_attr,
					       CMDQ_WORK2DISP_LOG_DATA_CHUNK_BSIZE,
					       &worker->work2disp_qp.qp_wq_rq_daddr,
					       &worker->work2disp_qp.qp_wq_sq_daddr,
					       &worker->work2disp_qp.qp_rqd_daddr,
					       &worker->work2disp_qp.qp_sqd_daddr,
					       &q->com_mkey, NULL, 0);
		if (retval)
			goto err_out;

		if (flexio_qp_create(process, process->ibv_ctx, &dev_qp_attr,
				     &q->work2disp_qp[i]) != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Cmd-q: flexio worker completion QP create failed");
			goto err_out;
		}

		if (modify_dbr(process, dev_qp_attr.qp_wq_dbr_qmem.daddr,
			       L2V(dev_qp_attr.log_rq_depth), 0))
		{
			flexio_err("Cmd-q: failed to init DEV QP DBR");
			goto err_out;
		}

		flexio_print(FLEXIO_LOG_LVL_DBG,
			     "Cmd-q: DEV worker %u to dispatcher job completion qp_num %#x",
			     i, q->work2disp_qp[i]->qp_num);
		worker->work2disp_qp.q_num = q->work2disp_qp[i]->qp_num;
		worker->work2disp_qp.dbr_daddr = dev_qp_attr.qp_wq_dbr_qmem.daddr;

		/* FlexIO QP transition - RST2INIT */
		dev_qp_attr.remote_qp_num = worker->work2disp_qp.q_num;
		dev_qp_attr.fl = 1;
		dev_qp_attr.min_rnr_nak_timer = 0x12;
		dev_qp_attr.path_mtu = FLEXIO_QP_QPC_MTU_BYTES_1K;
		dev_qp_attr.retry_count = 0x7;
		dev_qp_attr.vhca_port_num = 0x1;
		dev_qp_attr.next_state = FLEXIO_QP_STATE_INIT;
		if (flexio_qp_modify(q->work2disp_qp[i], &dev_qp_attr, &qp_fattr_opt_param_mask)
		    != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("cmd-q: failed to modify Flex IO worker QP from RST to INIT");
			goto err_out;
		}

		/* FlexIO QP transition - INIT2RTR */
		dev_qp_attr.next_state = FLEXIO_QP_STATE_RTR;
		if (flexio_qp_modify(q->work2disp_qp[i], &dev_qp_attr, &qp_fattr_opt_param_mask)
		    != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Failed to modify Flex IO QP from INIT to RTR");
			goto err_out;
		}

		/* FlexIO QP transition - RTR2RTS */
		dev_qp_attr.next_state = FLEXIO_QP_STATE_RTS;
		if (flexio_qp_modify(q->work2disp_qp[i], &dev_qp_attr, &qp_fattr_opt_param_mask)
		    != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Cmd-q: Failed to modify Flex IO QP from RTR to RTS");
			goto err_out;
		}

		worker_daddr = q->workers_data_daddr +
			       sizeof(struct flexio_dev_async_rpc_worker_data) * i;
		if (flexio_host2dev_memcpy(process, &q->worker_data[i],
					   sizeof(struct flexio_dev_async_rpc_worker_data),
					   worker_daddr) != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Cmd-q: Failed to copy memory to device\n");
			goto err_out;
		}

		if (flexio_event_handler_run(q->workers[i], worker_daddr) != FLEXIO_STATUS_SUCCESS)
		{
			flexio_err("Cmd-q: Failed to run worker event handler\n");
			goto err_out;
		}
	}

	if (flexio_buf_dev_alloc(process, sizeof(uint32_t) * fattr->workers,
				 &q->avail_workers_daddr) != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: Failed to allocate Flex IO memory");
		goto err_out;
	}
	async_rpc_data.avail_workers_daddr = q->avail_workers_daddr;

	if (flexio_buf_dev_alloc(process, CMDQ_DISP2WORK_BUF_BSIZE(fattr->batch_size),
				 &q->batch_buf_daddr) != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: Failed to allocate Flex IO memory");
		goto err_out;
	}
	async_rpc_data.batch_buf_daddr = q->batch_buf_daddr;

	if (flexio_copy_from_host(process, &async_rpc_data,
				  sizeof(struct flexio_dev_async_rpc_data),
				  &q->disp_data_daddr) != FLEXIO_STATUS_SUCCESS)
	{
		flexio_err("Cmd-q: Failed to copy date to Flex IO");
		goto err_out;
	}

	if (flexio_event_handler_run(q->dispatcher, q->disp_data_daddr) != FLEXIO_STATUS_SUCCESS) {
		flexio_err("Cmd-q: Failed to run cmd queue dispatcher\n");
		goto err_out;
	}

	*cmdq = q;

	return FLEXIO_STATUS_SUCCESS;

err_out:
	flexio_cmdq_destroy(q);

	return -FLEXIO_STATUS_FAILED;
}

flexio_status flexio_cmdq_task_add(struct flexio_cmdq *cmdq, flexio_func_t *host_func, uint64_t arg)
{
	struct flexio_dev_async_rpc_worker_param  worker_param = {0};
	struct flexio_func *dev_func_data = NULL;
	uint32_t byte_count;

	if (!cmdq)
		return -FLEXIO_STATUS_FAILED;

	if (get_dev_func_data(cmdq->process->app, host_func, &dev_func_data)) {
		flexio_err("Cmd-q: Failed to retrieve device func by host stub func\n");
		return -FLEXIO_STATUS_FAILED;
	}

	worker_param.entry_point = dev_func_data->dev_func_addr;
	worker_param.arg = arg;

	byte_count = sizeof(struct flexio_dev_async_rpc_worker_param);
	pthread_mutex_lock(&cmdq->task_add_mtx);
	host_qp_post_wqe(cmdq->host_qp, MLX5_CTRL_SEG_OPCODE_RDMA_SEND,
                         L2V(cmdq->job_log_data_bsize), &worker_param, byte_count);
	*cmdq->is_que_empty_haddr = 0;
	pthread_mutex_unlock(&cmdq->task_add_mtx);

	return FLEXIO_STATUS_SUCCESS;
}

int flexio_cmdq_is_empty(struct flexio_cmdq *cmdq)
{
	return cmdq ? *cmdq->is_que_empty_haddr : 0;
}

flexio_status flexio_cmdq_state_running(struct flexio_cmdq *cmdq)
{
	if (!cmdq)
		return -FLEXIO_STATUS_FAILED;

	if (cmdq->attr.state != FLEXIO_CMDQ_STATE_RUNNING) {
		cq_initial_arm(cmdq->job_cq->cq_num, cmdq->process->host_uar->base_addr);
		host_qp_post_wqe(cmdq->host_qp, MLX5_CTRL_SEG_OPCODE_NOP, 0, NULL, 0);
		cmdq->attr.state = FLEXIO_CMDQ_STATE_RUNNING;
	}

	return FLEXIO_STATUS_SUCCESS;
}

flexio_status flexio_cmdq_destroy(struct flexio_cmdq *cmdq)
{
	flexio_status ret = FLEXIO_STATUS_SUCCESS;
	int i;

	if (!cmdq)
		return ret;

	if (cmdq->host_qp)
		ret |= flexio_host_qp_destroy(cmdq->host_qp);
	if (cmdq->job_qp)
		ret |= flexio_qp_destroy(cmdq->job_qp);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->job_cq_dbr_daddr);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->job_cq_ring_daddr);
	if (cmdq->job_cq)
		ret |= flexio_cq_destroy(cmdq->job_cq);

	for (i = 0; cmdq->worker_data && i < cmdq->attr.workers; i++) {
		if (cmdq->disp2work_qp[i])
			ret |= flexio_qp_destroy(cmdq->disp2work_qp[i]);
		ret |= flexio_buf_dev_free(cmdq->process,
					   cmdq->worker_data[i].disp2work_qp.dbr_daddr);
		ret |= flexio_buf_dev_free(cmdq->process,
					   cmdq->worker_data[i].disp2work_qp.qp_wq_rq_daddr);

		if (cmdq->work2disp_qp[i])
			ret |= flexio_qp_destroy(cmdq->work2disp_qp[i]);

		ret |= flexio_buf_dev_free(cmdq->process,
					  cmdq->worker_data[i].work2disp_qp.dbr_daddr);
		ret |= flexio_buf_dev_free(cmdq->process,
					   cmdq->worker_data[i].work2disp_qp.qp_wq_rq_daddr);

		if (cmdq->worker_cq[i])
			ret |= flexio_cq_destroy(cmdq->worker_cq[i]);

		ret |= flexio_buf_dev_free(cmdq->process, cmdq->worker_data[i].worker_cq.dbr_daddr);
		ret |= flexio_buf_dev_free(cmdq->process,
					   cmdq->worker_data[i].worker_cq.cq_ring_daddr);
	}

	free(cmdq->work2disp_qp);
	free(cmdq->disp2work_qp);
	free(cmdq->worker_cq);

	for (i = 0; cmdq->worker_data && i < cmdq->attr.workers; i++) {
		if (cmdq->workers[i])
			ret |= flexio_event_handler_destroy(cmdq->workers[i]);
	}
	free(cmdq->workers);

	if (cmdq->cmpl_cq)
		ret |= flexio_cq_destroy(cmdq->cmpl_cq);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->cmpl_cq_dbr_daddr);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->cmpl_cq_ring_daddr);
	if (cmdq->dispatcher)
		ret |= flexio_event_handler_destroy(cmdq->dispatcher);
	if (cmdq->outbox)
		ret |= flexio_outbox_destroy(cmdq->outbox);
	if (cmdq->uar)
		ret |= flexio_uar_destroy(cmdq->uar);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->avail_workers_daddr);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->dpa_buf_daddr);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->workers_data_daddr);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->batch_buf_daddr);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->job_qp_rq_ring_daddr);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->job_qp_dbr_daddr);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->disp_data_daddr);
	ret |= flexio_buf_dev_free(cmdq->process, cmdq->qp_rqd_daddr);
	ret |= flexio_device_mkey_destroy(cmdq->job_qp_rqd_mkey);
	ret |= flexio_device_mkey_destroy(cmdq->com_mkey);
	ret |= flexio_window_destroy(cmdq->window);
	if (cmdq->mr)
		ret |= ibv_dereg_mr(cmdq->mr);
	free(cmdq->worker_data);
	free(cmdq->is_que_empty_haddr);
	pthread_mutex_destroy(&cmdq->task_add_mtx);
	free(cmdq);

	return ret;
}
