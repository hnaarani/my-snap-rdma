/*
 * SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <unistd.h>
#include <assert.h>
#include <signal.h>
#include <strings.h>
#include <string.h>

#include <libflexio/flexio.h>
#include <common/flexio_common_defs.h>

#include "flexio_log.h"
#include "flexio_priv.h"
#include "flexio_math.h"

#define STREAM_CFG_POINT "rpc_msg_stream_cfg"
#define STREAM_CLOSE_POINT "rpc_msg_stream_close"
#define STREAM_LEVEL_SET_POINT "msg_stream_level_set"
#define MSG_DEV_DATA_CHUNK_BSIZE (L2V(FLEXIO_MSG_DEV_LOG_DATA_CHUNK_BSIZE)) /* 512B limit */
#define MSG_DEV_LOG_QUEUES_DEPTH 6 /* 64 entries is enough */
#define LOG_QP_SWQE_BSIZE 6
#define FLEXIO_STREAM_NAME_MAX_SZ 32

typedef struct flexio_msg_stream {
	/* Stream configuration data */
	int stream_id;
	char stream_name[FLEXIO_STREAM_NAME_MAX_SZ];
	FILE *fout;
	flexio_msg_dev_level level;
	struct flexio_process *process;
	flexio_msg_dev_sync_mode sync_mode;

	int log_host_rings_depth; /* same depth for RQ, CQ and DATA buf */

	/* Host QP stuff */
	struct flexio_host_qp *host_qp;
	struct flexio_host_cq *host_cq;

	/* Dev QP stuff */
	struct flexio_qp *dev_qp;
	struct flexio_cq *dev_cq;
	flexio_uintptr_t dev_cq_ring_daddr;
	flexio_uintptr_t dev_cq_dbr_daddr;

	flexio_uintptr_t dev_qp_wq_buff_daddr;
	flexio_uintptr_t dev_qp_sq_daddr; /* SQ is a part of dev_qp_wq_buff_daddr. No free */
	/* _sqd_ for Send Queue Data */
	flexio_uintptr_t dev_sqd_daddr;

	/* Sync/Batch mode related stuff */
	pthread_t pthread;
	uint8_t flag_exit;

	/* Async/Batch mode related stuff */
	int log_host_data_bsize;
	char *host_data_haddr; /* allocated memory for RDMA write */
	struct ibv_mr *host_data_mr;

	/* Batch mode related stuff */
	uint8_t batch_count;

	/* Outbox for dev msg QP management */
	struct flexio_outbox *outbox;

	/* HART affinity information for stream management */
	struct flexio_affinity mgmt_affinity;

	/* Memory allocated for DEV side internal needs*/
	flexio_uintptr_t service_pi_ring_daddr;
	flexio_uintptr_t dev_msg_ctx_daddr;
	flexio_uintptr_t write_buf_daddr;
	flexio_uintptr_t stream_file_daddr;
	flexio_uintptr_t h2d_data_daddr;
	/**/
} msg_stream_ctx_t;

static int validate_and_arm_cqe(struct flexio_host_cq *hcq, struct mlx5_cqe64 *cqe)
{
	uint32_t opcode;

	opcode = mlx5dv_get_cqe_opcode(cqe);
	if (opcode == MLX5_CQE_REQ_ERR) {
		flexio_err("Got CQE with error on host CQ %#x", hcq->cq_num);
		return -FLEXIO_STATUS_FAILED;
	}

	/* Move forward CQ CI */
	hcq->cq_dbr[0] = htobe32(hcq->cqe_index & 0xffffff);

	return FLEXIO_STATUS_SUCCESS;
}

static void *msg_dev_sync_cb(void *arg)
{
	msg_stream_ctx_t *msg_stream_ctx = arg;
	struct flexio_host_qp *host_qp;
	struct mlx5_cqe64 *cqe;
	uint32_t wqe_counter;
	uint32_t byte_cnt;
	char *streambuf;

	host_qp = msg_stream_ctx->host_qp;
	while (!msg_stream_ctx->flag_exit) {
		/* Poll CQ */
		cqe = host_cq_get_cqe(msg_stream_ctx->host_cq);
		if (!cqe) {
			usleep(1000);
			continue;
		}

		if (validate_and_arm_cqe(msg_stream_ctx->host_cq, cqe))
			continue;

		wqe_counter = be16toh(cqe->wqe_counter);
		byte_cnt = be32toh(cqe->byte_cnt);

		streambuf = flexio_host_qp_wqe_data_get(msg_stream_ctx->host_qp, wqe_counter);
		streambuf[byte_cnt - 1] = 0; /* crash protection in case of broken data */

		fprintf(msg_stream_ctx->fout, "%s", streambuf);
		fflush(msg_stream_ctx->fout);
		host_qp->rq_pi_index++;
		host_qp->qp_dbr_haddr[0] = htobe32(host_qp->rq_pi_index & 0xffffff);
	}
	flexio_print(FLEXIO_LOG_LVL_DBG, "msg dev thread termination...");

	return NULL;
}

static void *msg_dev_batch_cb(void *arg)
{
	msg_stream_ctx_t *msg_stream_ctx = arg;
	struct flexio_host_qp *host_qp;
	struct mlx5_cqe64 *cqe;

	host_qp = msg_stream_ctx->host_qp;
	msg_stream_ctx->batch_count = 0;

	while (!msg_stream_ctx->flag_exit) {
		/* Poll CQ */
		cqe = host_cq_get_cqe(msg_stream_ctx->host_cq);
		if (!cqe) {
			usleep(1000);
			continue;
		}

		if (validate_and_arm_cqe(msg_stream_ctx->host_cq, cqe))
			continue;

		flexio_msg_stream_flush(msg_stream_ctx);

		host_qp->rq_pi_index++;
		host_qp->qp_dbr_haddr[0] = htobe32(host_qp->rq_pi_index & 0xffffff);
	}

	flexio_msg_stream_flush(msg_stream_ctx);

	return NULL;
}

static int destroy_msg_stream_resources(struct flexio_process *process, int stream_id)
{
	msg_stream_ctx_t *msg_stream_ctx = process->msg_stream_ctx[stream_id];
	int ret = 0;

	if (msg_stream_ctx->host_qp) {
		if (flexio_host_qp_destroy(msg_stream_ctx->host_qp)) {
			flexio_err("Failed to destroy msg dev HOST QP");
			ret = -1;
		}

		msg_stream_ctx->host_qp = NULL;
	}

	if (msg_stream_ctx->dev_qp) {
		if (flexio_qp_destroy(msg_stream_ctx->dev_qp)) {
			flexio_err("Failed to destroy msg dev DEV QP");
			ret = -1;
		}

		msg_stream_ctx->dev_qp = NULL;
	}

	if (flexio_buf_dev_free(process, msg_stream_ctx->dev_qp_wq_buff_daddr) ||
	    flexio_buf_dev_free(process, msg_stream_ctx->dev_sqd_daddr)) {
		flexio_err("Failed to free msg dev buffers from heap");
		ret = -1;
	}
	msg_stream_ctx->dev_qp_wq_buff_daddr = 0;
	msg_stream_ctx->dev_sqd_daddr = 0;

	if (msg_stream_ctx->host_cq) {
		if (host_cq_destroy(msg_stream_ctx->host_cq)) {
			flexio_err("Failed to destroy msg dev HOST CQ");
			ret = -1;
		}

		msg_stream_ctx->host_cq = NULL;
	}

	if (msg_stream_ctx->dev_cq) {
		if (flexio_cq_destroy(msg_stream_ctx->dev_cq)) {
			flexio_err("Failed to destroy msg dev DEV CQ");
			ret = -1;
		}

		msg_stream_ctx->dev_cq = NULL;
	}
	if (flexio_buf_dev_free(process, msg_stream_ctx->dev_cq_ring_daddr) ||
	    flexio_buf_dev_free(process, msg_stream_ctx->dev_cq_dbr_daddr)) {
		flexio_err("Failed to destroy msg dev DEV CQ memory\n");
		ret = -1;
	}
	msg_stream_ctx->dev_cq_ring_daddr = 0;
	msg_stream_ctx->dev_cq_dbr_daddr = 0;

	if (msg_stream_ctx->outbox) {
		if (flexio_outbox_destroy(msg_stream_ctx->outbox)) {
			flexio_err("Failed to destroy msg dev outbox");
			ret = -1;
		}

		msg_stream_ctx->outbox = NULL;
	}

	if (flexio_buf_dev_free(process, msg_stream_ctx->service_pi_ring_daddr)) {
		flexio_err("Failed to free service pi ring from heap");
		ret = -1;
	}
	msg_stream_ctx->service_pi_ring_daddr = 0;

	if (flexio_buf_dev_free(process, msg_stream_ctx->dev_msg_ctx_daddr)) {
		flexio_err("Failed to free dev msg ctx from heap");
		ret = -1;
	}
	msg_stream_ctx->dev_msg_ctx_daddr = 0;

	if (flexio_buf_dev_free(process, msg_stream_ctx->write_buf_daddr)) {
		flexio_err("Failed to free write buffer from heap");
		ret = -1;
	}
	msg_stream_ctx->write_buf_daddr = 0;

	if (flexio_buf_dev_free(process, msg_stream_ctx->stream_file_daddr)) {
		flexio_err("Failed to free stream file from heap");
		ret = -1;
	}
	msg_stream_ctx->stream_file_daddr = 0;

	if (flexio_buf_dev_free(process, msg_stream_ctx->h2d_data_daddr)) {
		flexio_err("Failed to free dev messaging stream cfg from heap");
		ret = -1;
	}

	if (msg_stream_ctx->host_data_mr) {
		if (ibv_dereg_mr(msg_stream_ctx->host_data_mr)) {
			flexio_err("Failed to deregister MR for host data");
			ret = -1;
		}

		msg_stream_ctx->host_data_mr = NULL;
	}

	free(msg_stream_ctx->host_data_haddr);
	msg_stream_ctx->host_data_haddr = NULL;

	process->msg_stream_ctx[stream_id] = NULL;
	free(msg_stream_ctx);
	return ret;
}

flexio_status flexio_log_dev_destroy(struct flexio_process *process)
{
	if (!process)
		return FLEXIO_STATUS_SUCCESS;

	return flexio_msg_stream_destroy(process->msg_stream_ctx[FLEXIO_MSG_DEV_DEFAULT_STREAM_ID]);
}

flexio_status flexio_msg_stream_destroy(struct flexio_msg_stream *stream)
{
	flexio_status ret = FLEXIO_STATUS_SUCCESS;
	struct flexio_process *process;
	uint64_t rpc_func_ret = 0;
	uint64_t stream_id_arg;

	if (!stream)
		return FLEXIO_STATUS_SUCCESS;

	process = stream->process;

	if (process->ref_count.num_of_threads) {
		flexio_err("BUG - calling flexio_log_dev_destroy before destroying all threads\n");
		flexio_err("%u threads should be destroyed\n", process->ref_count.num_of_threads);
		return -FLEXIO_STATUS_FAILED;
	}

	stream_id_arg = stream->stream_id;

	if (!flexio_err_status_get(process)) {
		if (non_packed_process_call(process, STREAM_CLOSE_POINT, stream_id_arg,
					    &stream->mgmt_affinity, &rpc_func_ret)) {
			flexio_err("Failed to call msg stream close dev handler\n");
			ret = -FLEXIO_STATUS_FAILED;
		}

		if (rpc_func_ret & 1ul << 63)
			flexio_err("DEV msg stream closing error. Syndrome %#lx\n", rpc_func_ret);
		else if (rpc_func_ret) {
			flexio_err("%lu symbols where flushed to msg dev queue. Wait...\n",
				   rpc_func_ret);
			/* If return value is not zero, some data was flushed during close call.
			 * Let's permit OS to switch context and print flushed data */
			sleep(1);
		}
	}

	if (stream->pthread) {
		stream->flag_exit = true;
		/* Wait for child termination */
		pthread_join(stream->pthread, NULL);
		stream->pthread = 0;
	}

	if (destroy_msg_stream_resources(process, stream->stream_id))
		ret = -FLEXIO_STATUS_FAILED;

	return ret;
}

static int msg_dev_cq_mem_alloc(struct flexio_process *process, int log_cq_depth,
				msg_stream_ctx_t *msg_stream_ctx)
{
	msg_stream_ctx->dev_cq_dbr_daddr = qalloc_dbr(process);
	if (!msg_stream_ctx->dev_cq_dbr_daddr) {
		flexio_err("Failed to alloc DBR for CQ\n");
		return -1;
	}

	msg_stream_ctx->dev_cq_ring_daddr = qalloc_cq_ring(process, log_cq_depth);
	if (!msg_stream_ctx->dev_cq_ring_daddr) {
		flexio_err("Failed to alloc CQ ring\n");
		return -1;
	}
	return 0;
}

static int internal_msg_stream_create(struct flexio_process *process, int stream_id,
				      flexio_msg_stream_attr_t *stream_fattr, FILE *out,
				      pthread_t *ppthread)
{
	struct flexio_qp_attr_opt_param_mask host_qp_attr_opt_param_mask = {0};
	struct flexio_qp_attr dev_qp_fattr = {0}, host_qp_modify_attr = {0};
	struct flexio_qp_attr_opt_param_mask qp_fattr_opt_param_mask = {0};
	struct flexio_host_qp_attr host_qp_fattr = {0};
	struct flexio_outbox_attr outbox_attr = {0};
	struct flexio_cq_attr dev_cq_fattr = {0};
	struct lib_transfer_msg_dev h2d_data;
	msg_stream_ctx_t *msg_stream_ctx;
	int log_dev_qp_sq_ring_bsize;
	int log_host_data_bsize;
	uint64_t rpc_func_ret;
	pthread_t pthread;
	int err;

	void *(*pthread_func_ptr)(void *) = NULL;

	if (!stream_fattr->uar || !out) {
		flexio_err("Illegal process/flexio_uar/out argument: NULL");
		return -1;
	}

	switch (stream_fattr->sync_mode) {
	case FLEXIO_LOG_DEV_SYNC_MODE_SYNC:
	case FLEXIO_LOG_DEV_SYNC_MODE_ASYNC:
	case FLEXIO_LOG_DEV_SYNC_MODE_BATCH:
		break;

	default:
		flexio_err("Illegal sync mode: %d given in stream attributes",
			   stream_fattr->sync_mode);
		return -1;
	}

	/* Validation received data */
	if (!process->elf_buff) {
		flexio_err("Cant init msg dev module without DEV elf loaded");
		return -1;
	}

	if (!is_power_of_two(stream_fattr->data_bsize)) {
		flexio_err("Buffer size MUST be power of two");
		return -1;
	}

	if (stream_fattr->data_bsize < MSG_DEV_DATA_CHUNK_BSIZE) {
		flexio_err("Buffer size MUST be at least one chunk size %#lx",
			   MSG_DEV_DATA_CHUNK_BSIZE);
		return -1;
	}

	/* Context */
	msg_stream_ctx = calloc(1, sizeof(msg_stream_ctx_t));
	assert(msg_stream_ctx);
	process->msg_stream_ctx[stream_id] = msg_stream_ctx;

	/* How much data chunks includes data_bsize */
	log_host_data_bsize = ffs(stream_fattr->data_bsize) - 1;
	msg_stream_ctx->log_host_data_bsize = log_host_data_bsize;
	msg_stream_ctx->log_host_rings_depth =
		log_host_data_bsize - FLEXIO_MSG_DEV_LOG_DATA_CHUNK_BSIZE;

	/* Validate input for BATCH sync mode */
	if ((stream_fattr->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_BATCH) &&
	    (msg_stream_ctx->log_host_rings_depth < 3)) {
		flexio_err("For using the batch sync mode, receiver queue must have at least 8 "
			   "entries");
		goto err_out;
	}

	/* Allocate & configure stream. */
	/* By default the default stream's name will be default_stream */
	msg_stream_ctx->stream_id = stream_id;
	msg_stream_ctx->fout = out;
	msg_stream_ctx->level = stream_fattr->level;
	msg_stream_ctx->process = process;
	strncpy(msg_stream_ctx->stream_name, stream_fattr->stream_name, FLEXIO_STREAM_NAME_MAX_SZ - 1);
	msg_stream_ctx->stream_name[FLEXIO_STREAM_NAME_MAX_SZ - 1] = '\0';
	msg_stream_ctx->sync_mode = stream_fattr->sync_mode;

	/******************* HOST QP creation ********************/
	err = host_cq_create(process->ibv_ctx, msg_stream_ctx->log_host_rings_depth,
			     process->host_uar, &msg_stream_ctx->host_cq);
	if (err) {
		flexio_err("Failed to create HOST CQ for msg dev handling");
		goto err_out;
	}

	host_qp_fattr.log_wq_buffer_depth = msg_stream_ctx->log_host_rings_depth;
	host_qp_fattr.log_data_chunk_bsize = FLEXIO_MSG_DEV_LOG_DATA_CHUNK_BSIZE;
	host_qp_fattr.uar_id = process->host_uar->page_id;
	host_qp_fattr.cq_num = msg_stream_ctx->host_cq->cq_num;
	host_qp_fattr.is_rdma = stream_fattr->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_ASYNC ||
				stream_fattr->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_BATCH;
	host_qp_fattr.pd = process->internal_pd;
	host_qp_fattr.no_sq = 1;
	host_qp_fattr.rq_type = FLEXIO_QP_QPC_RQ_TYPE_REGULAR;
	err = flexio_host_qp_create(process->internal_pd, process->ibv_ctx, process->hca_caps,
				    &host_qp_fattr, &msg_stream_ctx->host_qp);

	if (err) {
		flexio_err("Failed to create HOST QP for msg dev handling");
		goto err_out;
	}

	flexio_print(FLEXIO_LOG_LVL_DBG, "Print: HOST qp_num %#x", msg_stream_ctx->host_qp->qp_num);
	/******************* DEV QP creation ********************/
	err = flexio_buf_dev_alloc(process, L2V(MSG_DEV_LOG_QUEUES_DEPTH +
						FLEXIO_MSG_DEV_LOG_DATA_CHUNK_BSIZE),
				   &msg_stream_ctx->dev_sqd_daddr);
	if (err) {
		flexio_err("Failed to allocate heap memory for msg dev device buffer");
		goto err_out;
	}

	dev_cq_fattr.log_cq_depth = MSG_DEV_LOG_QUEUES_DEPTH;
	dev_cq_fattr.element_type = FLEXIO_CQ_ELEMENT_TYPE_NON_DPA_CQ;
	dev_cq_fattr.uar_id = stream_fattr->uar->aliasable.id;

	if (msg_dev_cq_mem_alloc(process, dev_cq_fattr.log_cq_depth, msg_stream_ctx))
		goto err_out;

	dev_cq_fattr.cq_dbr_daddr = msg_stream_ctx->dev_cq_dbr_daddr;
	dev_cq_fattr.cq_ring_qmem.daddr = msg_stream_ctx->dev_cq_ring_daddr;

	err = flexio_cq_create(process, NULL, &dev_cq_fattr, &msg_stream_ctx->dev_cq);
	if (err) {
		flexio_err("Failed to create DEV CQ for msg dev handling");
		goto err_out;
	}

	log_dev_qp_sq_ring_bsize = MSG_DEV_LOG_QUEUES_DEPTH + LOG_QP_SWQE_BSIZE;
	msg_stream_ctx->dev_qp_wq_buff_daddr = qalloc_qp_wq_buff(process, 0, NULL,
								 log_dev_qp_sq_ring_bsize,
								 &msg_stream_ctx->dev_qp_sq_daddr);

	if (!msg_stream_ctx->dev_qp_wq_buff_daddr) {
		flexio_err("Failed to allocate memory for msg dev QP");
		goto err_out;
	}

	dev_qp_fattr.transport_type = FLEXIO_QPC_ST_RC;
	dev_qp_fattr.log_sq_depth = MSG_DEV_LOG_QUEUES_DEPTH;
	dev_qp_fattr.uar_id = stream_fattr->uar->aliasable.id;
	dev_qp_fattr.sq_cqn = msg_stream_ctx->dev_cq->cq_num;
	dev_qp_fattr.rq_cqn = msg_stream_ctx->dev_cq->cq_num; /* RQ's CQ is not used. Therefore,
	                                                       *  initialization done with any available CQ
	                                                       */
	dev_qp_fattr.pd = process->internal_pd;
	dev_qp_fattr.no_sq = 0;
	dev_qp_fattr.rq_type = FLEXIO_QP_QPC_RQ_TYPE_ZERO_SIZE_RQ;
	dev_qp_fattr.qp_wq_buff_qmem.daddr = msg_stream_ctx->dev_qp_wq_buff_daddr;
	dev_qp_fattr.qp_wq_dbr_qmem.memtype = FLEXIO_MEMTYPE_DPA;

	err = flexio_qp_create(process, NULL, &dev_qp_fattr, &msg_stream_ctx->dev_qp);
	if (err) {
		flexio_err("Failed to create DEV QP for msg dev handling");
		goto err_out;
	}
	flexio_print(FLEXIO_LOG_LVL_DBG, "Print: DEV qp_num %#x", msg_stream_ctx->dev_qp->qp_num);

	/* connect qp dev and qp host */
	host_qp_modify_attr.remote_qp_num = msg_stream_ctx->dev_qp->qp_num;
	host_qp_modify_attr.qp_access_mask = IBV_ACCESS_REMOTE_WRITE;
	host_qp_modify_attr.fl = 1; /* force loop-back is ON */
	host_qp_modify_attr.min_rnr_nak_timer = 0x12;
	host_qp_modify_attr.path_mtu = FLEXIO_QP_QPC_MTU_BYTES_1K;
	host_qp_modify_attr.vhca_port_num = 0x1;
	host_qp_modify_attr.next_state = FLEXIO_QP_STATE_INIT;
	/* Host QP transition - RST2INIT */
	err = flexio_host_qp_modify(msg_stream_ctx->host_qp, &host_qp_modify_attr,
				    &host_qp_attr_opt_param_mask);
	if (err) {
		flexio_err("Failed to transition Host QP from RST to INIT");
		goto err_out;
	}

	host_qp_modify_attr.next_state = FLEXIO_QP_STATE_RTR;
	/* Host QP transition - INIT2RTR */
	err = flexio_host_qp_modify(msg_stream_ctx->host_qp, &host_qp_modify_attr,
				    &host_qp_attr_opt_param_mask);
	if (err) {
		flexio_err("Failed to transition Host QP from INIT to RTR");
		goto err_out;
	}

	host_qp_modify_attr.next_state = FLEXIO_QP_STATE_RTS;
	/* Host QP transition - RTR2RTS */
	err = flexio_host_qp_modify(msg_stream_ctx->host_qp, &host_qp_modify_attr,
				    &host_qp_attr_opt_param_mask);
	if (err) {
		flexio_err("Failed to transition Host QP from RTR to RTS");
		goto err_out;
	}

	dev_qp_fattr.remote_qp_num = msg_stream_ctx->host_qp->qp_num;
	dev_qp_fattr.fl = 1;
	dev_qp_fattr.min_rnr_nak_timer = 0x12;
	dev_qp_fattr.path_mtu = FLEXIO_QP_QPC_MTU_BYTES_1K;
	dev_qp_fattr.retry_count = 0x7;
	dev_qp_fattr.vhca_port_num = 0x1;
	dev_qp_fattr.next_state = FLEXIO_QP_STATE_INIT;
	/* FlexIO QP transition - RST2INIT */
	err = flexio_qp_modify(msg_stream_ctx->dev_qp, &dev_qp_fattr, &qp_fattr_opt_param_mask);
	if (err) {
		flexio_err("Failed to transition Flex IO QP from RST to INIT");
		goto err_out;
	}

	dev_qp_fattr.next_state = FLEXIO_QP_STATE_RTR;
	/* FlexIO QP transition - INIT2RTR */
	err = flexio_qp_modify(msg_stream_ctx->dev_qp, &dev_qp_fattr, &qp_fattr_opt_param_mask);
	if (err) {
		flexio_err("Failed to transition Flex IO QP from INIT to RTR");
		goto err_out;
	}

	dev_qp_fattr.next_state = FLEXIO_QP_STATE_RTS;
	/* FlexIO QP transition - RTR2RTS */
	err = flexio_qp_modify(msg_stream_ctx->dev_qp, &dev_qp_fattr, &qp_fattr_opt_param_mask);
	if (err) {
		flexio_err("Failed to transition Flex IO QP from RTR to RTS");
		goto err_out;
	}

	outbox_attr.uar = stream_fattr->uar;
	err = flexio_outbox_create(process, process->ibv_ctx, &outbox_attr,
				   &msg_stream_ctx->outbox);
	if (err) {
		flexio_err("Failed to create Flex IO outbox for msg dev mechanism");
		goto err_out;
	}

	/* Allocating device memory for stream context */
	err = flexio_buf_dev_alloc(process, L2V(MSG_DEV_LOG_QUEUES_DEPTH),
				   &msg_stream_ctx->service_pi_ring_daddr);
	if (err) {
		flexio_err("Failed to heap alloc mem for service_pi_ring\n");
		goto err_out;
	}

	err = flexio_buf_dev_alloc(process, MSG_DEV_CTX_STRUCT_BSIZE,
				   &msg_stream_ctx->dev_msg_ctx_daddr);
	if (err) {
		flexio_err("Failed to heap alloc mem for dev_msg_ctx_daddr\n");
		goto err_out;
	}

	err = flexio_buf_dev_alloc(process, BUFSIZ, &msg_stream_ctx->write_buf_daddr);
	if (err) {
		flexio_err("Failed to heap alloc mem for write_buf_daddr\n");
		goto err_out;
	}

	err = flexio_buf_dev_alloc(process, MSG_DEV_STRUCT_FLEXIO_FILE_DEV_BSIZE,
				   &msg_stream_ctx->stream_file_daddr);
	if (err) {
		flexio_err("Failed to heap alloc mem for stream_file_daddr\n");
		goto err_out;
	}

	/* Pass data to DEV application */
	memset(&h2d_data, 0, sizeof(h2d_data));
	h2d_data.dev_lkey = process->internal_dumem_mkey->id;
	h2d_data.outbox_id = msg_stream_ctx->outbox->outbox_id;
	h2d_data.log_sq_depth = MSG_DEV_LOG_QUEUES_DEPTH;
	h2d_data.log_data_chunk_bsize = FLEXIO_MSG_DEV_LOG_DATA_CHUNK_BSIZE;
	h2d_data.sqd_daddr = msg_stream_ctx->dev_sqd_daddr;
	h2d_data.qp_sq_daddr = msg_stream_ctx->dev_qp_sq_daddr;
	h2d_data.qp_num = msg_stream_ctx->dev_qp->qp_num;
	h2d_data.service_pi_ring_daddr = msg_stream_ctx->service_pi_ring_daddr;

	h2d_data.cq_num = msg_stream_ctx->dev_cq->cq_num;
	h2d_data.log_cq_depth = MSG_DEV_LOG_QUEUES_DEPTH;
	h2d_data.cq_dbr_daddr = msg_stream_ctx->dev_cq_dbr_daddr;
	h2d_data.cq_ring_daddr = msg_stream_ctx->dev_cq_ring_daddr;
	h2d_data.sync_mode = stream_fattr->sync_mode;
	h2d_data.stream_id = msg_stream_ctx->stream_id;
	h2d_data.stream_level = msg_stream_ctx->level;
	h2d_data.dev_msg_ctx_daddr = msg_stream_ctx->dev_msg_ctx_daddr;
	h2d_data.write_buf_daddr = msg_stream_ctx->write_buf_daddr;
	h2d_data.stream_file_daddr = msg_stream_ctx->stream_file_daddr;

	if ((stream_fattr->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_ASYNC) ||
	    (stream_fattr->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_BATCH)) {
		/* Async mode supposed RDMA write to HOST buffer */
		msg_stream_ctx->host_data_haddr = calloc(1, stream_fattr->data_bsize);
		assert(msg_stream_ctx->host_data_haddr);

		msg_stream_ctx->host_data_mr = ibv_reg_mr(process->internal_pd,
							  msg_stream_ctx->host_data_haddr,
							  stream_fattr->data_bsize,
							  IBV_ACCESS_LOCAL_WRITE |
							  IBV_ACCESS_REMOTE_WRITE);
		if (!msg_stream_ctx->host_data_mr) {
			flexio_err("Failed to create host MR to receive device messages");
			goto err_out;
		}

		h2d_data.log_host_data_bsize = log_host_data_bsize;
		h2d_data.host_data_haddr = (uint64_t)msg_stream_ctx->host_data_haddr;
		h2d_data.host_lkey = msg_stream_ctx->host_data_mr->lkey;
	}

	err = flexio_copy_from_host(process, &h2d_data, sizeof(struct lib_transfer_msg_dev),
				    &msg_stream_ctx->h2d_data_daddr);
	if (err) {
		flexio_err("Failed to copy h2d_data to DEV\n");
		goto err_out;
	}

	msg_stream_ctx->mgmt_affinity = stream_fattr->mgmt_affinity;
	err = non_packed_process_call(process, STREAM_CFG_POINT, msg_stream_ctx->h2d_data_daddr,
				      &msg_stream_ctx->mgmt_affinity, &rpc_func_ret);

	if (err) {
		flexio_err("Failed to call msg stream config dev handler\n");
		goto err_out;
	}

	/* Prepare thread function pointer */
	if (stream_fattr->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_SYNC)
		pthread_func_ptr = msg_dev_sync_cb;
	else if (stream_fattr->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_BATCH)
		pthread_func_ptr = msg_dev_batch_cb;

	if ((stream_fattr->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_SYNC) ||
	    (stream_fattr->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_BATCH)) {
		msg_stream_ctx->flag_exit = false;
		err = pthread_create(&pthread, NULL, pthread_func_ptr, msg_stream_ctx);
		if (err) {
			flexio_err("Failed to create msg stream's pthread - %s\n", strerror(err));
			goto err_out;
		}

		msg_stream_ctx->pthread = pthread;
		if (ppthread)
			*ppthread = pthread;
	}

	return 0;

err_out:
	destroy_msg_stream_resources(process, stream_id);
	return -1;
}

flexio_status flexio_log_dev_init(struct flexio_process *process,
				  flexio_msg_stream_attr_t *stream_fattr, FILE *out,
				  pthread_t *ppthread)
{
	int err;

	if (!stream_fattr || !process) {
		flexio_err("Illegal process/flexio_msg_stream_attr_t arguments: NULL");
		return -FLEXIO_STATUS_FAILED;
	}

	if (process->msg_stream_ctx[FLEXIO_MSG_DEV_DEFAULT_STREAM_ID]) {
		flexio_err("Default msg stream for device messages was already created");
		return -FLEXIO_STATUS_FAILED;
	}

	/* By default the default stream's name will be default_stream */
	stream_fattr->stream_name = "default_stream";
	stream_fattr->level = FLEXIO_MSG_DEV_INFO;

	err = internal_msg_stream_create(process, FLEXIO_MSG_DEV_DEFAULT_STREAM_ID, stream_fattr,
					 out, ppthread);
	if (err)
		return -FLEXIO_STATUS_FAILED;

	return FLEXIO_STATUS_SUCCESS;
}

flexio_status flexio_msg_stream_create(struct flexio_process *process,
				       flexio_msg_stream_attr_t *stream_fattr, FILE *out,
				       pthread_t *ppthread, struct flexio_msg_stream **stream)
{
	char tmp_name[FLEXIO_STREAM_NAME_MAX_SZ];
	int err;
	int i;

	if (!process || !stream_fattr || !stream) {
		flexio_err("Illegal stream_fattr argument: NULL");
		return -FLEXIO_STATUS_FAILED;
	}

	/* Search for available stream ID */
	for (i = 0; i < FLEXIO_MSG_DEV_MAX_STREAMS_AMOUNT; ++i) {
		if (!process->msg_stream_ctx[i])
			break;
	}

	if (i == 0) {
		stream_fattr->stream_name = "default_stream";
		stream_fattr->level = FLEXIO_MSG_DEV_INFO;
	}

	if (i == FLEXIO_MSG_DEV_MAX_STREAMS_AMOUNT) {
		flexio_err("Reached max amount of %d streams available to create",
			   FLEXIO_MSG_DEV_MAX_STREAMS_AMOUNT);
		return -FLEXIO_STATUS_FAILED;
	}

	/* Validating the attributes given */
	if (!((stream_fattr->level >= FLEXIO_MSG_DEV_ERROR) &&
	      (stream_fattr->level <= FLEXIO_MSG_DEV_DEBUG)) &&
	    (stream_fattr->level != FLEXIO_MSG_DEV_NO_PRINT)) {
		flexio_err("Illegal flexio_msg_dev_level given: %d", stream_fattr->level);
		return -FLEXIO_STATUS_FAILED;
	}

	if (!stream_fattr->stream_name) {
		snprintf(tmp_name, FLEXIO_STREAM_NAME_MAX_SZ, "stream_num_%d", i);
		stream_fattr->stream_name = tmp_name;
	}

	err = internal_msg_stream_create(process, i, stream_fattr, out, ppthread);
	if (err)
		return -FLEXIO_STATUS_FAILED;

	*stream = process->msg_stream_ctx[i];
	flexio_print(FLEXIO_LOG_LVL_DBG, "Successfully created FlexIO dev msg stream, id: %d", i);
	return FLEXIO_STATUS_SUCCESS;
}

flexio_status flexio_log_dev_flush(struct flexio_process *process)
{
	if (!process)
		return FLEXIO_STATUS_SUCCESS;

	return flexio_msg_stream_flush(process->msg_stream_ctx[FLEXIO_MSG_DEV_DEFAULT_STREAM_ID]);
}

flexio_status flexio_msg_stream_flush(struct flexio_msg_stream *stream)
{
	char tmp_buf[MSG_DEV_DATA_CHUNK_BSIZE + 1]; /* last symbol reserved for null termination */
	char *data_iter_cpy;
	char *data_iter;
	char *data_end;

	if (!stream)
		return FLEXIO_STATUS_SUCCESS;

	if (stream->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_SYNC)
		return FLEXIO_STATUS_SUCCESS;
	else if (stream->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_ASYNC) {
		data_iter = stream->host_data_haddr;
		data_end = stream->host_data_haddr + L2V(stream->log_host_data_bsize);
	} else { /* stream->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_BATCH */
		data_iter = stream->host_data_haddr + ((stream->batch_count &
							(L2V(stream->log_host_rings_depth) /
							 MSG_DEV_MAX_BATCH_AMOUNT - 1)) *
						       MSG_DEV_MAX_BATCH_AMOUNT *
						       MSG_DEV_DATA_CHUNK_BSIZE);
		data_end = data_iter + MSG_DEV_DATA_CHUNK_BSIZE * MSG_DEV_MAX_BATCH_AMOUNT;
		stream->batch_count++;
	}

	data_iter_cpy = data_iter;
	tmp_buf[MSG_DEV_DATA_CHUNK_BSIZE] = 0;
	for (; data_iter < data_end; data_iter += MSG_DEV_DATA_CHUNK_BSIZE) {
		memcpy(tmp_buf, data_iter, MSG_DEV_DATA_CHUNK_BSIZE);
		fprintf(stream->fout, "%s", tmp_buf);
	}

	if (stream->sync_mode == FLEXIO_LOG_DEV_SYNC_MODE_BATCH)
		memset(data_iter_cpy, 0, MSG_DEV_DATA_CHUNK_BSIZE * MSG_DEV_MAX_BATCH_AMOUNT);

	return FLEXIO_STATUS_SUCCESS;
}

int flexio_msg_stream_get_id(struct flexio_msg_stream *stream)
{
	if (!stream) {
		flexio_err("Illegal stream argument: NULL\n");
		return -1;
	}

	return stream->stream_id;
}

flexio_status flexio_msg_stream_level_set(struct flexio_msg_stream *stream,
					  flexio_msg_dev_level level)
{
	uint64_t stream_modify_args = 0;
	uint64_t rpc_func_ret;
	uint8_t *arg_arr;
	int err;

	if (!stream) {
		flexio_err("illegal stream argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!((level >= FLEXIO_MSG_DEV_ERROR) && (level <= FLEXIO_MSG_DEV_DEBUG)) &&
	    (level != FLEXIO_MSG_DEV_NO_PRINT)) {
		flexio_err("Illegal flexio_msg_dev_level given\n");
		return -FLEXIO_STATUS_FAILED;
	}

	arg_arr = (uint8_t *)&stream_modify_args;
	arg_arr[STREAM_MODIFY_ARGS_STREAM_ID_INDEX] = stream->stream_id;
	arg_arr[STREAM_MODIFY_ARGS_STREAM_LEVEL_INDEX] = level;

	err = non_packed_process_call(stream->process, STREAM_LEVEL_SET_POINT, stream_modify_args,
				      &stream->mgmt_affinity, &rpc_func_ret);
	if (err) {
		flexio_err("Failed to call stream create dev modify handler\n");
		return -FLEXIO_STATUS_FAILED;
	}

	/* coverity[uninit_use] rpc_func_ret */
	if (rpc_func_ret) {
		flexio_err("Failed to change stream's level, make sure the stream exists\n");
		return -FLEXIO_STATUS_FAILED;
	}

	flexio_print(FLEXIO_LOG_LVL_DBG, "Stream %d have changed its level successfully\n",
		     stream->stream_id);
	return FLEXIO_STATUS_SUCCESS;
}
