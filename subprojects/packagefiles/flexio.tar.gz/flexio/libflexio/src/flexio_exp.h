/*
 * SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __FLEXIO_EXP_H__
#define __FLEXIO_EXP_H__

#include <common/flexio_common_structs.h>
#include <stdint.h>

#if !defined (EXPOSE_DATA)
/*************************************************************************************
* Place here structures and definitions, FULLY exposed for NVIDIA developers
*************************************************************************************/
#define ALIAS_ACCESS_KEY_NUM_DWORD              8
struct flexio_aliasable_obj {
	uint32_t access_key[ALIAS_ACCESS_KEY_NUM_DWORD];        /* Access key is 256b long */
	uint32_t id;
	uint16_t type;
	uint8_t is_allowed;
	uint8_t is_supported;
};

struct flexio_cq {
	uint32_t cq_num;
	struct flexio_process *process;
	struct mlx5dv_devx_obj *devx_cq;
	struct flexio_alias *alias_dumem;
	struct flexio_alias *alias_thread;
};

struct flexio_rq {
	uint32_t wq_num;
	struct flexio_process *process;
	struct mlx5dv_devx_obj *devx_rq;
	struct mlx5dv_devx_obj *tir;
	struct flexio_transport_domain *td;
	struct flexio_alias *alias_dumem;
	struct flexio_mkey *rqd_mkey;
};

struct flexio_sq {
	uint32_t wq_num;
	struct flexio_process *process;
	struct mlx5dv_devx_obj *devx_sq;
	struct mlx5dv_devx_obj *tis;
	struct flexio_transport_domain *td;
	uint32_t tis_num;
	struct flexio_alias *alias_dumem;
};

struct flexio_qp {
	flexio_qp_state state;
	uint32_t qp_num;
	struct mlx5dv_devx_obj *devx_qp;
	struct flexio_process *process;
	struct ibv_context *ibv_ctx;

	/* allocated memory */
	struct flexio_alias *alias_dumem;
};

struct flexio_window {
	uint32_t mkey_id;
	uint32_t window_id;
	struct flexio_process *process;
	struct mlx5dv_devx_obj *devx_window;
	struct flexio_alias *alias_pd;
};

struct flexio_outbox {
	uint32_t outbox_id;
	struct flexio_process *process;
	struct mlx5dv_devx_obj *devx_outbox;
	struct flexio_alias *alias_dev_uar;
	struct flexio_uar *orig_flexio_uar;
};

struct flexio_thread {
	struct flexio_aliasable_obj aliasable;
	struct flexio_host_sq *trigger_sq;
	struct flexio_process *process;
	struct mlx5dv_devx_uar *internal_uar;
	struct mlx5dv_devx_obj *devx_thread;
	struct flexio_thread_metadata *metadata;
	flexio_uintptr_t metadata_daddr;
	flexio_uintptr_t priv_stack_daddr;
	flexio_uintptr_t cont_data_daddr;
};

struct flexio_event_handler {
	struct flexio_thread *thread;
};

/*************************************************************************************
* Place here prototypes of functions, exposed only for NVIDIA developers
*************************************************************************************/

#endif

/*************************************************************************************
* Place here structures and definitions, PARTIALLY exposed for NVIDIA developers
*************************************************************************************/

/* Exposed flexio_process provides access only for dedicated list of fields */
#if !defined (__FLEXIO_PRIV_H__)
struct flexio_process {
#endif
#if !defined (__FLEXIO_PRIV_H__) || defined (EXPOSE_PROCESS)
struct ibv_context *ibv_ctx;
struct ibv_pd *internal_pd;
struct mlx5dv_devx_uar *host_uar;
struct mlx5dv_devx_obj *devx_process;
struct flexio_aliasable_obj dumem;
struct flexio_window *window;
struct flexio_outbox *outbox;
struct flexio_uar *internal_uar;

uint32_t process_id;
flexio_uintptr_t code_segment_base_daddr;
flexio_uintptr_t heap_process_umem_base_daddr;
#endif
#if !defined (__FLEXIO_PRIV_H__)
};
#endif
#endif
