/*
 * SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <sys/stat.h>
#include <elf.h>
#include <assert.h>
#include "flexio_log.h"
#include "flexio_priv.h"

static int validate_elf_header(void *elf_buf, size_t buf_size)
{
	Elf64_Ehdr *header = (Elf64_Ehdr *)elf_buf;

	/* Verify buffer size is at least ELF header size */
	if (buf_size < (long)sizeof(Elf64_Ehdr)) {
		flexio_err("ELF buffer size %ld is smaller than ELF header size %lu\n",
			   buf_size, sizeof(Elf64_Ehdr));
		return -1;
	}

	/* Verify ELF Identification */
	if ((header->e_ident[EI_MAG0] != ELFMAG0) ||
	    (header->e_ident[EI_MAG1] != ELFMAG1) ||
	    (header->e_ident[EI_MAG2] != ELFMAG2) ||
	    (header->e_ident[EI_MAG3] != ELFMAG3))
	{
		flexio_err("File does not start with ELF magic '%#x'ELF\n", ELFMAG0);
		return -1;
	}

	/* Verify ELF class and data type */
	if (header->e_ident[EI_CLASS] != ELFCLASS64) {
		flexio_err("ELF class is not ELF64\n");
		return -1;
	}
	if (header->e_ident[EI_DATA] != ELFDATA2LSB) {
		flexio_err("ELF data type is not LE\n");
		return -1;
	}

	/* Verify section table is valid */
	if (header->e_shoff == SHN_UNDEF) {
		flexio_err("ELF section header table offset is undefined\n");
		return -1;
	}
	if (header->e_shentsize != sizeof(Elf64_Shdr)) {
		flexio_err("ELF section table entry size %u is not equal to sizeof(Elf64_Shdr)\n",
			   header->e_shentsize);
		return -1;
	}
	/* coverity[sign_extension] */
	if (header->e_shoff + (header->e_shnum * header->e_shentsize) > buf_size) {
		flexio_err("ELF section header table exceeds ELF size %lu\n", buf_size);
		return -1;
	}
	if (header->e_shstrndx == SHN_UNDEF) {
		flexio_err("ELF section header string section index is undefined\n");
		return -1;
	}
	if (header->e_shstrndx >= header->e_shnum) {
		flexio_err("ELF section header string section index %u exceed e_shnum %u\n",
			   header->e_shstrndx, header->e_shnum);
		return -1;
	}

	return 0;
}

static int get_sections_name_sec(char *elf_buf, char **sec_loc, uint64_t *sec_size)
{
	Elf64_Shdr *sec_tbl, *sec_hdr;
	Elf64_Ehdr *header;

	header = (Elf64_Ehdr *)elf_buf;

	if ((header->e_shoff == SHN_UNDEF) || (header->e_shstrndx == SHN_UNDEF))
		return -1;

	sec_tbl = (Elf64_Shdr *)(elf_buf + header->e_shoff);
	sec_hdr = sec_tbl + header->e_shstrndx;
	*sec_loc = elf_buf + sec_hdr->sh_offset;
	*sec_size = sec_hdr->sh_size;

	return 0;
}

static int find_section_by_name(char *elf_buf, const char *name, Elf64_Shdr **sec_hdr_out)
{
	Elf64_Shdr *sec_tbl, *sec_hdr;
	uint64_t str_sec_size;
	Elf64_Ehdr *header;
	char *sh_str_tbl;
	uint32_t i;

	header = (Elf64_Ehdr *)elf_buf;

	if (get_sections_name_sec(elf_buf, &sh_str_tbl, &str_sec_size)) {
		flexio_err("Failed to locate sections name section\n");
		return -1;
	}

	sec_tbl = (Elf64_Shdr *)(elf_buf + header->e_shoff);
	for (i = 0; i < header->e_shnum; i++) {
		sec_hdr = sec_tbl + i;
		if (strcmp(sh_str_tbl + sec_hdr->sh_name, name) == 0) {
			*sec_hdr_out = sec_hdr;
			return 0;
		}
	}

	return -1;
}

int elf_get_sym_val(char *elf_buf, size_t buf_size, const char *sym_name, uint64_t *sym_val)
{
	Elf64_Sym *sym_tbl, *sym_data;
	uint64_t sym_sec_size;
	Elf64_Shdr *sec_data;
	uint32_t found = 0;
	char *str_tbl;
	char *name;
	int err;

	if (!elf_buf || !sym_name || !sym_val) {
		flexio_err("illegal elf_buf/sym_name/sym_val argument: NULL\n");
		return -1;
	}

	err = validate_elf_header(elf_buf, buf_size);
	if (err)
		return -1;

	/* Locate symbol and string tables */
	if (find_section_by_name(elf_buf, ".strtab", &sec_data)) {
		flexio_err("Failed to locate section .strtab\n");
		return -1;
	}
	if (sec_data->sh_offset + sec_data->sh_size > buf_size) {
		flexio_err(".strtab section exceeds ELF buffer size %lu\n", buf_size);
		return -1;
	}
	str_tbl = elf_buf + sec_data->sh_offset;
	if (find_section_by_name(elf_buf, ".symtab", &sec_data)) {
		flexio_err("Failed to locate section .symtab\n");
		return -1;
	}
	if (sec_data->sh_offset + sec_data->sh_size > buf_size) {
		flexio_err(".symtab section exceeds ELF buffer size %lu\n", buf_size);
		return -1;
	}
	sym_tbl = (Elf64_Sym*)(elf_buf + sec_data->sh_offset);
	sym_sec_size = sec_data->sh_size;

	/* Find symbol value */
	for (sym_data = sym_tbl; sym_data < sym_tbl + sym_sec_size / sizeof(Elf64_Sym); sym_data++) {
		name = str_tbl + sym_data->st_name;
		if (name && strcmp(sym_name, name) == 0) {
			*sym_val = sym_data->st_value;
			found++;
		}
	}

	if (found > 1) {
		flexio_err("Symbol %s appears %u times in ELF symbol table\n", sym_name, found);
		return -1;
	}
	else if (found == 0)
		return -1;

	return 0;
}

int elf_get_section_val(char *elf_buf, size_t buf_size, const char *sec_name, uint64_t *sec_off,
			uint64_t *sec_size)
{
	Elf64_Shdr *sec_data;
	int err;

	err = validate_elf_header(elf_buf, buf_size);
	if (err)
		return -1;

	/* Locate the required section by name */
	if (find_section_by_name(elf_buf, sec_name, &sec_data)) {
		flexio_err("Failed to locate section name %s\n", sec_name);
		return -1;
	}
	if (sec_data->sh_offset + sec_data->sh_size > buf_size) {
		flexio_err("%s section exceeds ELF buffer size %lu\n", sec_name, buf_size);
		return -1;
	}

	*sec_off = sec_data->sh_offset;
	*sec_size = sec_data->sh_size;

	return 0;
}

int get_elf_file(const char *file_name, void **elf_buf, size_t *buf_size)
{
	FILE *file = NULL;
	long file_size;
	int err;

	*elf_buf = NULL;
	*buf_size = 0;

	file = fopen(file_name, "rb");
	if (!file) {
		flexio_err("Failed to open file %s\n", file_name);
		goto err_out;
	}

	/* Get file size */
	if (fseek(file, 0, SEEK_END) == -1) {
		flexio_err("Failed to fseek to SEEK_END file %s\n", file_name);
		goto err_out;
	}
	file_size = ftell(file);
	if (file_size == -1) {
		flexio_err("Failed to ftell file %s\n", file_name);
		goto err_out;
	}
	if (file_size < (long)sizeof(Elf64_Ehdr)) {
		flexio_err("ELF file size %ld is smaller than ELF header size %lu\n",
			   file_size, sizeof(Elf64_Ehdr));
		goto err_out;
	}
	if (fseek(file, 0, SEEK_SET) == -1) {
		flexio_err("Failed to fseek SEEK_SET file %s\n", file_name);
		goto err_out;
	}

	err = posix_memalign(elf_buf, 64, file_size);
	assert(err == 0);
	assert(*elf_buf);
	memset(*elf_buf, 0, file_size);

	*buf_size = fread(*elf_buf, 1, file_size, file);
	if (*buf_size != (uint64_t)file_size) {
		flexio_err("Read %lu bytes from file %s but its size is %ld\n",
			   *buf_size, file_name, file_size);
		goto err_out;
	}

	err = validate_elf_header(*elf_buf, *buf_size);
	if (err)
		goto err_out;

	*buf_size = file_size;
	fclose(file);

	return 0;

err_out:
	if (file)
		fclose(file);
	free(*elf_buf);
	return -1;
}
