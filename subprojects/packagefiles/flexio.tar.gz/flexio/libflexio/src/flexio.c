/*
 * SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <malloc.h>
#include <dlfcn.h>
#include <errno.h>
#include <unistd.h>
#include <stdatomic.h>
#include <stdarg.h>

#include <libflexio/flexio.h>
#include "flexio_log.h"
#include "flexio_math.h"
#include "flexio_prm.h"
#include "flexio_priv.h"
#include "ccan/isaac/isaac.h"

#define LOG_FLEXIO_SWQE_BSIZE 6

/* Service Functions for internal usage. */
void _align_host_umem_id_to_24b(struct mlx5dv_devx_umem *umem)
{
	umem->umem_id &= 0x00ffffff;
}

int _alloc_transport_domain(struct ibv_context *ibv_ctx, struct flexio_transport_domain **td)
{
	*td = calloc(1, sizeof(struct flexio_transport_domain));
	assert(*td);

	(*td)->obj = flexio_create_prm_transport_domain(ibv_ctx, &((*td)->id));
	if (!(*td)->obj) {
		flexio_err("Failed to allocate transport domain");
		goto err_create;
	}

	return FLEXIO_STATUS_SUCCESS;

err_create:
	free(*td);
	*td = NULL;
	return errno;
}

int _dealloc_transport_domain(struct flexio_transport_domain *td)
{
	int err;

	if (td == NULL)
		return 0;

	err = mlx5dv_devx_obj_destroy(td->obj);
	if (err) {
		flexio_err("Failed to destroy transport domain (err = %d)", err);
		td->obj = NULL;
	}

	free(td);

	return err;
}

static void generate_alias_access_key(struct flexio_aliasable_obj *obj)
{
	struct isaac_ctx ctx;
	int i;

	isaac_init(&ctx, NULL, 0);
	for (i = 0; i < ALIAS_ACCESS_KEY_NUM_DWORD; i++)
		obj->access_key[i] = isaac_next_uint32(&ctx);
}

static int allow_access_to_object(struct ibv_context *ctx, struct flexio_aliasable_obj *obj)
{
	struct flexio_prm_allow_other_vhca_access_attr attr;
	int i, err;

	if (!obj->is_supported) {
		flexio_err("Creating an alias for object type '%#x' is not supported", obj->type);
		return -1;
	}
	attr.type = obj->type;
	attr.obj_id = obj->id;
	generate_alias_access_key(obj);
	for (i = 0; i < ALIAS_ACCESS_KEY_NUM_DWORD; i++)
		attr.access_key_be[i] = htobe32(obj->access_key[i]);

	err = flexio_allow_other_vhca_access_prm_cmd(ctx, &attr);
	if (err)
		flexio_err("Failed to allow access to object");
	else
		obj->is_allowed = 1;

	return err;
}

struct flexio_alias *create_flexio_alias(struct ibv_context *orig_ctx, struct ibv_context *ctx,
					 uint32_t orig_vhca_id, struct flexio_aliasable_obj *obj)
{
	struct flexio_prm_alias_attr attr;
	struct flexio_alias *alias;
	int i, err;

	alias = calloc(1, sizeof(*alias));
	assert(alias);

	if (!obj->is_allowed) {
		err = allow_access_to_object(orig_ctx, obj);
		if (err) {
			flexio_err("Failed to allow access to object");
			goto err_allow;
		}
	}

	attr.orig_vhca_id = orig_vhca_id;
	attr.type = obj->type;
	attr.orig_obj_id = obj->id;
	for (i = 0; i < ALIAS_ACCESS_KEY_NUM_DWORD; i++)
		attr.access_key_be[i] = htobe32(obj->access_key[i]);

	alias->devx_obj = flexio_create_prm_alias(ctx, &attr, &alias->id);
	if (!alias->devx_obj) {
		flexio_err("Failed to create alias");
		goto err_create_alias;
	}

	return alias;

err_create_alias:
err_allow:
	free(alias);
	return NULL;
}

int check_create_alias_dumem(struct flexio_process *process, struct ibv_context *ibv_ctx,
				    struct flexio_alias **dumem_alias, uint32_t *dumem_id)
{
	struct flexio_prm_hca_caps *other_vhca_caps = NULL;
	flexio_status ret = -FLEXIO_STATUS_FAILED;

	*dumem_alias = NULL;
	if (ibv_ctx) {
		other_vhca_caps = flexio_query_prm_hca_caps(ibv_ctx);
		if (!other_vhca_caps) {
			flexio_err("Failed to query HCA capabilities of other VHCA");
			goto out;
		}
	}

	if (ibv_ctx && process->hca_caps->gvmi != other_vhca_caps->gvmi) {
		*dumem_alias = create_flexio_alias(process->ibv_ctx, ibv_ctx,
						   process->hca_caps->gvmi, &process->dumem);
		if (!*dumem_alias) {
			flexio_err("Failed to create alias for process DUMEM");
			goto out;
		}
	}

	*dumem_id = *dumem_alias ? (*dumem_alias)->id : process->dumem.id;
	ret = FLEXIO_STATUS_SUCCESS;

out:
	free(other_vhca_caps);
	return ret;
}

static int check_create_alias_pd(struct flexio_process *process, struct ibv_context *ibv_ctx,
				 struct flexio_aliasable_obj *orig_pd,
				 struct flexio_alias **pd_alias, uint32_t *pdn)
{
	struct flexio_prm_hca_caps *other_vhca_caps = NULL;
	flexio_status ret = -FLEXIO_STATUS_FAILED;

	*pd_alias = NULL;
	if (ibv_ctx) {
		other_vhca_caps = flexio_query_prm_hca_caps(ibv_ctx);
		if (!other_vhca_caps) {
			flexio_err("Failed to query HCA capabilities of other VHCA");
			goto out;
		}
	}

	if (ibv_ctx && process->hca_caps->gvmi != other_vhca_caps->gvmi) {
		*pd_alias = create_flexio_alias(ibv_ctx, process->ibv_ctx, other_vhca_caps->gvmi,
						orig_pd);
		if (!*pd_alias) {
			flexio_err("Failed to create alias for PD");
			goto out;
		}
	}

	*pdn = *pd_alias ? (*pd_alias)->id : orig_pd->id;
	ret = FLEXIO_STATUS_SUCCESS;

out:
	free(other_vhca_caps);
	return ret;
}

static int check_create_alias_uar(struct flexio_process *process, struct ibv_context *ibv_ctx,
				  struct flexio_aliasable_obj *orig_uar,
				  struct flexio_alias **uar_alias, uint32_t *uar_id)
{
	struct flexio_prm_hca_caps *other_vhca_caps = NULL;
	flexio_status ret = -FLEXIO_STATUS_FAILED;

	*uar_alias = NULL;
	if (ibv_ctx) {
		other_vhca_caps = flexio_query_prm_hca_caps(ibv_ctx);
		if (!other_vhca_caps) {
			flexio_err("Failed to query HCA capabilities of other VHCA");
			goto out;
		}
	}

	if (ibv_ctx && process->hca_caps->gvmi != other_vhca_caps->gvmi) {
		*uar_alias = create_flexio_alias(ibv_ctx, process->ibv_ctx, other_vhca_caps->gvmi,
						 orig_uar);
		if (!*uar_alias) {
			flexio_err("Failed to create alias for UAR");
			goto out;
		}
	}

	*uar_id = *uar_alias ? (*uar_alias)->id : orig_uar->id;
	ret = FLEXIO_STATUS_SUCCESS;

out:
	free(other_vhca_caps);
	return ret;
}

static int create_process_dumem_mkey(struct flexio_process *process)
{
	struct flexio_mkey_attr attr = {0};
	int err;

	attr.pd = process->internal_pd;
	/* Create an internal MKey for the entire DUMEM */
	attr.daddr = process->heap_process_umem_base_daddr;
	attr.len = L2V(process->hca_caps->log_max_num_dpa_mem_blocks) *
		   process->hca_caps->dpa_mem_block_size;
	attr.access = IBV_ACCESS_LOCAL_WRITE;
	err = flexio_device_mkey_create(process, &attr, &process->internal_dumem_mkey);
	if (err) {
		flexio_err("Failed to create process internal device UMEM MKey ID");
		goto err_out;
	}

	return FLEXIO_STATUS_SUCCESS;

err_out:
	return -FLEXIO_STATUS_FAILED;
}

static void set_process_attr(struct flexio_process *process)
{
	process->caps.max_num_of_threads = L2V(process->hca_caps->log_max_dpa_thread);
	process->caps.max_num_of_outboxes = L2V(process->hca_caps->log_max_dpa_outbox);
	process->caps.max_num_of_windows = L2V(process->hca_caps->log_max_dpa_window);
}

int dev_cq_mem_alloc(struct flexio_process *process, int log_cq_depth,
		     flexio_uintptr_t *cq_dbr_daddr_p, flexio_uintptr_t *cq_ring_daddr_p)
{
	*cq_dbr_daddr_p = qalloc_dbr(process);
	*cq_ring_daddr_p = qalloc_cq_ring(process, log_cq_depth);

	if (!*cq_dbr_daddr_p || !*cq_ring_daddr_p)
		return -1;
	return 0;
}

#define FLEXIO_RPC_MAX_POLL_RETRIES 6000
#define FLEXIO_RPC_USLEEP_TIME 10000
#define FLEXIO_HW_RPC_WRAPPER_FUNC_NAME "flexio_hw_rpc"
static int process_call(struct flexio_process *process, flexio_uintptr_t dev_func_addr,
			struct flexio_dev_func_params *dev_func_params, size_t func_params_size,
			uint64_t *func_ret)
{
	struct flexio_host_sq_attr host_sq_attr = {0};
	struct flexio_prm_thread_attr prm_attr = {0};
	struct flexio_host_sq *rpc_trigger_sq = NULL;
	struct flexio_thread_attr thread_attr = {0};
	struct flexio_rpc_poll *rpc_poll = NULL;
	struct flexio_cq_attr cq_attr = {0};
	flexio_uintptr_t thread_data = 0;
	flexio_uintptr_t func_symbol_val;
	flexio_uintptr_t cq_ring_daddr;
	flexio_uintptr_t cq_dbr_daddr;
	struct flexio_rpc_data *data;
	struct flexio_thread *thread;
	size_t data_to_dev_size;
	struct flexio_cq *cq;
	struct ibv_mr *mr;
	int err, index;

	err = elf_get_sym_val(process->elf_buff, process->elf_size, FLEXIO_HW_RPC_WRAPPER_FUNC_NAME,
			      &func_symbol_val);
	if (err) {
		flexio_err("Failed to find symbol value of %s in ELF file",
			   FLEXIO_HW_RPC_WRAPPER_FUNC_NAME);
		return -FLEXIO_STATUS_FAILED;
	}

	/* Control path */
	err = posix_memalign((void**)&rpc_poll, 64, sizeof(*rpc_poll));
	if (err) {
		flexio_err("Failed to allocate memory (posix_memalign failed\n");
		return -FLEXIO_STATUS_FAILED;
	}
	memset(rpc_poll, 0, sizeof(*rpc_poll));

	mr = ibv_reg_mr(process->internal_pd, rpc_poll, 64, IBV_ACCESS_LOCAL_WRITE);
	if (!mr) {
		flexio_err("Failed to create MR for RPC polling address");
		err = -FLEXIO_STATUS_FAILED;
		goto err_mr;
	}

	if (flexio_buf_dev_alloc(process, sizeof(*data) + func_params_size, &thread_data)) {
		flexio_err("Failed to allocate heap memory for RPC thread data");
		goto err_alloc_mem;
	}

	prm_attr.process_id = process->process_id;

	prm_attr.user_argument = thread_data;
	prm_attr.outbox_id = 0;
	thread_attr.dev_func_addr = func_symbol_val;
	thread_attr.affinity.type = FLEXIO_AFFINITY_NONE;
	err = create_thread(process, &prm_attr, &thread_attr, &thread);
	if (err) {
		flexio_err("Failed to create thread");
		goto err_create_thread;
	}

	cq_attr.element_type = FLEXIO_CQ_ELEMENT_TYPE_DPA_THREAD;
	cq_attr.thread = thread;
	cq_attr.uar_id = process->host_uar->page_id;
	cq_attr.uar_base_addr = process->host_uar->base_addr;

	if (dev_cq_mem_alloc(process, 0, &cq_dbr_daddr, &cq_ring_daddr)) {
		flexio_err("Failed to allocate memory for CQ\n");
		goto err_cq_create;
	}

	cq_attr.cq_dbr_daddr = cq_dbr_daddr;
	cq_attr.cq_ring_qmem.daddr = cq_ring_daddr;
	err = flexio_cq_create(process, NULL, &cq_attr, &cq);
	if (err) {
		flexio_err("Failed to create CQ");
		goto err_cq_create;
	}

	err = flexio_modify_prm_thread(thread->devx_thread, thread->aliasable.id, 0 /*thread_data*/,
				       FLEXIO_THREAD_STATE_RUNNING);
	if (err) {
		flexio_err("Failed to start thread");
		return -FLEXIO_STATUS_FAILED;
	}

	host_sq_attr.cq_num = cq->cq_num;
	host_sq_attr.log_num_entries = LOG_NUM_HOST_SQ_DEPTH;
	host_sq_attr.log_wqe_bsize = LOG_FLEXIO_SWQE_BSIZE;
	err = host_sq_create(process, &host_sq_attr, &rpc_trigger_sq);
	if (err) {
		flexio_err("Failed to create RPC trigger SQ");
		goto err_create_host_sq;
	}

	rpc_trigger_sq->agent_cq = cq;
	rpc_trigger_sq->agent_cq_dbr_daddr = cq_dbr_daddr;
	rpc_trigger_sq->agent_cq_ring_daddr = cq_ring_daddr;

	/* Data path */
	data_to_dev_size = sizeof(*data) + func_params_size;
	data = calloc(1, data_to_dev_size);
	assert(data);

	data->poll_lkey = mr->lkey;
	data->window_id = process->window->window_id;
	data->poll_haddr = (uint64_t)mr->addr;
	data->entry_point = dev_func_addr;
	memcpy(&data->func_params, dev_func_params, func_params_size);
	err = flexio_host2dev_memcpy(process, data, data_to_dev_size, thread_data);
	if (err) {
		flexio_err("Failed to copy RPC data from host to Flex IO");
		goto err_data_path;
	}

	free(data);
	data = NULL;

	host_sq_post_nop_wqe(rpc_trigger_sq);
	for (index = 0; index < FLEXIO_RPC_MAX_POLL_RETRIES; index++) {
		if (rpc_poll->flag)
			break;

		usleep(FLEXIO_RPC_USLEEP_TIME);

		/* In case of fatal error no way to release resources */
		if (flexio_err_status(process)) {
			flexio_err("Fatal error on RPC polling");
			err = -FLEXIO_STATUS_FATAL_ERR;
			goto err_fatal_error;
		}

	}
	if (index == FLEXIO_RPC_MAX_POLL_RETRIES) {
		flexio_err("Timeout on RPC polling");
		err = -FLEXIO_STATUS_TIMEOUT;
		goto err_data_path;
	}

	*func_ret = rpc_poll->return_value;
	free(rpc_poll);
	rpc_poll = NULL;

	err = host_sq_destroy(rpc_trigger_sq);
	if (err) {
		flexio_err("Failed to destroy RPC trigger SQ");
		goto err_destroy_host_sq;
	}
	rpc_trigger_sq = NULL;

	err = flexio_thread_destroy(thread);
	if (err) {
		flexio_err("Failed to destroy RPC thread");
		goto err_thread_destroy;
	}

	err = flexio_buf_dev_free(process, thread_data);
	if (err) {
		flexio_err("Failed to free thread argument heap memory");
		goto err_free_mem;
	}

	err = ibv_dereg_mr(mr);
	if (err) {
		flexio_err("Failed to deregister MR for RPC polling");
		goto err_out;
	}

	return FLEXIO_STATUS_SUCCESS;

err_fatal_error:
err_data_path:
	free(data);

	host_sq_destroy(rpc_trigger_sq);
	cq = NULL;
err_create_host_sq:
	if (cq) {
		flexio_cq_destroy(cq);
		/* coverity[check_return] */
		flexio_buf_dev_free(process, cq_dbr_daddr);
		/* coverity[check_return] */
		flexio_buf_dev_free(process, cq_ring_daddr);
	}
err_destroy_host_sq:
err_cq_create:
	flexio_thread_destroy(thread);
err_create_thread:
err_thread_destroy:
	/* coverity[check_return] */
	flexio_buf_dev_free(process, thread_data);
err_free_mem:
err_alloc_mem:
	ibv_dereg_mr(mr);
err_mr:
	free(rpc_poll);
err_out:
	if (err == -FLEXIO_STATUS_TIMEOUT || err == -FLEXIO_STATUS_FATAL_ERR)
		/* coverity[mixed_enum_type] */
		return err;
	else
		return -FLEXIO_STATUS_FAILED;
}

flexio_status flexio_process_call(struct flexio_process *process, flexio_func_t *host_func,
				  uint64_t *func_ret, ... /* args for the user function */)
{
	struct flexio_dev_func_params *dev_func_params;
	struct flexio_func *dev_func_data = NULL;
	size_t dev_func_params_size;
	va_list ap;
	int err;

	if (!process || !func_ret) {
		flexio_err("Illegal process/func_ret argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (get_dev_func_data(process->app, host_func, &dev_func_data)) {
		flexio_err("Failed to retrieve device func by host stub func\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!dev_func_data->pup) {
		flexio_err("Device func was registered without pack/unpack info\n");
		return -FLEXIO_STATUS_FAILED;
	}

	dev_func_params_size = sizeof(*dev_func_params) + dev_func_data->argbuf_size;
	dev_func_params = calloc(1, dev_func_params_size);
	assert(dev_func_params);

	dev_func_params->func_wo_pack = 0;
	dev_func_params->dev_func_entry = dev_func_data->dev_func_addr;
	va_start(ap, func_ret);
	dev_func_data->arg_pack_fn(&dev_func_params->arg_buf, ap);
	va_end(ap);

	err = process_call(process, dev_func_data->dev_unpack_func_addr, dev_func_params,
			   dev_func_params_size, func_ret);

	free(dev_func_params);

	/* coverity[mixed_enum_type] */
	return err;
}

int non_packed_process_call(struct flexio_process *process, const char* dev_func_name,
			    uint64_t arg, uint64_t *func_ret)
{
	struct flexio_dev_func_params *dev_func_params;
	flexio_uintptr_t dev_func_addr;
	size_t dev_func_params_size;
	int err;

	if (!process) {
		flexio_err("Illegal process argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (elf_get_sym_val(process->elf_buff, process->elf_size, dev_func_name, &dev_func_addr)) {
		flexio_err("Failed to find device function %s in app ELF", dev_func_name);
		return -FLEXIO_STATUS_FAILED;
	}

	dev_func_params_size = sizeof(*dev_func_params);
	dev_func_params = calloc(1, dev_func_params_size);
	assert(dev_func_params);

	dev_func_params->func_wo_pack = 1;
	dev_func_params->dev_func_entry = 0;
	dev_func_params->arg_buf = arg;

	err = process_call(process, dev_func_addr, dev_func_params, dev_func_params_size, func_ret);

	free(dev_func_params);

	return err;
}

static flexio_status process_create(struct ibv_context *ibv_ctx, struct flexio_app *app,
				    const struct flexio_process_attr *process_attr,
				    struct flexio_process **process_ptr)
{
	struct ibv_mr *dev_app_mr = NULL, *sig_mr = NULL;
	struct flexio_prm_process_attr prm_attr = {0};
	struct flexio_host_sq_attr host_sq_attr = {0};
	struct flexio_prm_hca_caps *hca_caps;
	struct flexio_process *process;
	struct flexio_host_sq *ctrl_sq;
	struct mlx5dv_devx_obj *obj;
	struct flexio_host_cq *hcq;
	int err;

	hca_caps = flexio_query_prm_hca_caps(ibv_ctx);
	if (!hca_caps) {
		flexio_err("Failed to query HCA capabilities");
		goto err_out;
	}

	if (!(hca_caps->has_dpa && hca_caps->has_dpa_process_obj &&
	      hca_caps->has_dpa_thread_obj && hca_caps->has_dpa_mem_obj)) {
		flexio_err("Device doesn't support minimal required DPA objects");
		goto err_hca_caps;
	}

	process = calloc(1, sizeof(*process));
	assert(process);

	process->ibv_ctx = ibv_ctx;
	process->hca_caps = hca_caps;
	set_process_attr(process);

	process->dumem.type = MLX5_GENERAL_OBJECT_TYPES_DPA_DUMEM;
	process->dumem.is_supported = process->hca_caps->umem_allowed_supported;

	if (process_attr && process_attr->pd) {
		process->internal_pd = process_attr->pd;
	} else {
		process->internal_pd = ibv_alloc_pd(ibv_ctx);
		if (!process->internal_pd) {
			flexio_err("Failed to allocate PD");
			goto err_create_pd;
		}
		process->destroy_pd = true;
	}

	process->elf_buff = app->elf_buffer;
	process->elf_size = app->elf_size;
	dev_app_mr = ibv_reg_mr(process->internal_pd, process->elf_buff, app->elf_size, 0);
	if (!dev_app_mr) {
		flexio_err("Failed to create MR for ELF file");
		goto err_create_mr;
	}

	process->host_uar = mlx5dv_devx_alloc_uar(process->ibv_ctx, 0x1);
	if (!process->host_uar) {
		flexio_err("Failed to allocate host UAR");
		goto err_alloc_uar;
	}

	/* Signature (crypto data) */
	if (app->sig_exist) {
		sig_mr = ibv_reg_mr(process->internal_pd, app->sig_buffer, app->sig_size, 0);
		if (!sig_mr) {
			flexio_err("Failed to create MR for ELF signature");
			goto err_handle_sig;
		}
		prm_attr.sig_mkey = sig_mr->lkey;
		prm_attr.sig_size = app->sig_size;
		prm_attr.sig_haddr = (uint64_t)app->sig_buffer;
	}

	prm_attr.mkey = dev_app_mr->lkey;
	prm_attr.file_size = app->elf_size;
	prm_attr.bin_haddr = (uint64_t)dev_app_mr->addr;
	obj = flexio_create_prm_process(process->ibv_ctx, &prm_attr, &process->process_id);
	if (!obj) {
		flexio_err("Failed to create process");
		goto err_create_process;
	}

	ibv_dereg_mr(dev_app_mr);
	dev_app_mr = NULL;

	if (sig_mr) {
		ibv_dereg_mr(sig_mr);
		sig_mr = NULL;
	}

	process->devx_process = obj;
	err = flexio_query_prm_process(obj, process->process_id, &process->dumem.id,
				       &process->heap_process_umem_base_daddr,
				       &process->code_segment_base_daddr);
	if (err) {
		flexio_err("Failed to query the process properties");
		goto err_query_process;
	}

	heap_init(process);

	/* Create an MKey for the entire process DUMEM. */
	err = create_process_dumem_mkey(process);
	if (err) {
		flexio_err("Failed to create process device UMEM MKey");
		goto err_create_mkey;
	}

	/* Create process window. */
	if (flexio_window_create(process, process->internal_pd, &process->window)) {
		flexio_err("Failed to create process window");
		goto err_create_window;
	}

	if (flexio_modify_prm_process(process->devx_process, process->process_id,
				      MLX5_DPA_PROCESS_MODIFY_FIELD_SELECT_WINDOW_PRIMARY,
				      process->window->window_id))
	{
		flexio_err("Failed to set process primary window\n");
		goto err_set_primary_window;
	}

	/* Create an SQ for LDMA WQE posting. */
	err = host_cq_create(process->ibv_ctx, 2, process->host_uar, &hcq);
	if (err) {
		flexio_err("Failed to create CQ for control SQ");
		goto err_create_host_cq;
	}

	/* coverity[uninit_use] hcq */
	host_sq_attr.cq_num = hcq->cq_num;
	host_sq_attr.log_num_entries = LOG_NUM_HOST_SQ_DEPTH;
	host_sq_attr.log_wqe_bsize = LOG_FLEXIO_SWQE_BSIZE;
	err = host_sq_create(process, &host_sq_attr, &ctrl_sq);
	if (err) {
		flexio_err("Failed to create control SQ");
		goto err_create_host_sq;
	}

	/* coverity[uninit_use] ctrl_sq */
	ctrl_sq->host_cq = hcq;
	process->ctrl_sq = ctrl_sq;
	process->current_thread_id = 0;

	/* Create error handling stuff */
	if (_error_event_register(process))
		goto err_event_register;

	*process_ptr = process;

	return FLEXIO_STATUS_SUCCESS;

err_event_register:
err_create_host_sq:
	host_cq_destroy(hcq);
err_create_host_cq:
err_set_primary_window:
	flexio_window_destroy(process->window);
err_create_window:
err_create_mkey:
err_query_process:
err_create_process:
	if (sig_mr)
		ibv_dereg_mr(sig_mr);
err_handle_sig:
err_alloc_uar:
	if (dev_app_mr)
		ibv_dereg_mr(dev_app_mr);
err_create_mr:
err_create_pd:
	flexio_process_destroy(process);
	hca_caps = NULL;
err_hca_caps:
	free(hca_caps);
err_out:
	*process_ptr = NULL;
	return -FLEXIO_STATUS_FAILED;
}

flexio_status flexio_process_create(struct ibv_context *ibv_ctx, struct flexio_app *app,
				    const struct flexio_process_attr *process_attr,
				    struct flexio_process **process_ptr)
{
	int err;

	if (!ibv_ctx) {
		flexio_err("Illegal ibv context argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!app) {
		flexio_err("Illegal application argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (app->elf_size == 0) {
		flexio_err("Application ELF size is 0\n");
		return -FLEXIO_STATUS_FAILED;
	}

	err = process_create(ibv_ctx, app, process_attr, process_ptr);
	if (err != FLEXIO_STATUS_SUCCESS)
		goto err_elf_buf;

	(*process_ptr)->app = app;

	return FLEXIO_STATUS_SUCCESS;

err_elf_buf:
	return -FLEXIO_STATUS_FAILED;
}

flexio_status flexio_process_destroy(struct flexio_process *process)
{
	flexio_status ret = FLEXIO_STATUS_SUCCESS;
	int err;

	if (!process)
		return ret;

	if (process->print_ctx) {
		flexio_err("print_ctx is not NULL - need to call flexio_print_destroy");
		return -FLEXIO_STATUS_FAILED;
	}

	if (process->event_channel) {
		mlx5dv_devx_destroy_event_channel(process->event_channel);
		process->event_channel = NULL;
	}

	err = host_sq_destroy(process->ctrl_sq);
	if (err) {
		flexio_err("Failed to destroy control SQ");
		ret = -FLEXIO_STATUS_FAILED;
	}

	err = flexio_window_destroy(process->window);
	if (err) {
		flexio_err("Failed to destroy window");
		ret = -FLEXIO_STATUS_FAILED;
	}

	err = flexio_device_mkey_destroy(process->internal_dumem_mkey);
	if (err) {
		flexio_err("Failed to destroy dumem Mkey (err = %d)", err);
		ret = -FLEXIO_STATUS_FAILED;
	}

	err = heap_destroy(process);
	if (err) {
		flexio_err("Failed to release prm heap memory");
		ret = -FLEXIO_STATUS_FAILED;
	}

	if (process->devx_process) {
		err = mlx5dv_devx_obj_destroy(process->devx_process);
		if (err) {
			flexio_err("Failed to destroy process PRM object (err = %d)", err);
			ret = -FLEXIO_STATUS_FAILED;
		}
		process->devx_process = NULL;
	}

	if (process->host_uar) {
		mlx5dv_devx_free_uar(process->host_uar);
		process->host_uar = NULL;
	}

	if (process->destroy_pd && process->internal_pd) {
		err = ibv_dealloc_pd(process->internal_pd);
		if (err) {
			flexio_err("Failed to deallocate PD (err = %d)", err);
			ret = -FLEXIO_STATUS_FAILED;
		}
		process->internal_pd = NULL;
	}

	free(process->hca_caps);
	free(process);

	return ret;
}

flexio_status flexio_window_create(struct flexio_process *process, struct ibv_pd *pd,
				   struct flexio_window **window)
{
	struct flexio_aliasable_obj aliasable_pd = {0};
	struct flexio_prm_window_attr attr = {0};

	if (!process || !pd || !window) {
		flexio_err("illegal process/pd/window argument: NULL\n");
		goto err_out;
	}

	if (!process->hca_caps->has_dpa_window_obj) {
		flexio_err("DPA window creation is not supported by this device");
		goto err_out;
	}

	if (process->ref_count.num_of_windows >= process->caps.max_num_of_windows) {
		flexio_err("Max number of windows per process reached");
		goto err_out;
	}

	aliasable_pd.id = flexio_query_pdn(pd);
	if (aliasable_pd.id == UINT32_MAX) {
		flexio_err("Failed to get PD number");
		goto err_out;
	}

	*window = calloc(1, sizeof(struct flexio_window));
	assert(*window);

	aliasable_pd.type = MLX5_GENERAL_OBJECT_TYPES_PD;
	aliasable_pd.is_supported = process->hca_caps->pd_allowed_supported;
	if (check_create_alias_pd(process, pd->context, &aliasable_pd, &(*window)->alias_pd,
				   &attr.pdn))
		goto err_create_alias;

	attr.process_id = process->process_id;

	(*window)->devx_window = flexio_create_prm_window(process->ibv_ctx, &attr,
							  &(*window)->window_id);
	if ((*window)->devx_window == NULL) {
		flexio_err("Failed to create Flex IO window");
		goto err_create;
	}

	(*window)->process = process;
	process->ref_count.num_of_windows++;

	return FLEXIO_STATUS_SUCCESS;

err_create:
err_create_alias:
	flexio_window_destroy(*window);
err_out:
	if(window)
		*window = NULL;
	return -FLEXIO_STATUS_FAILED;
}

flexio_status flexio_window_destroy(struct flexio_window *window)
{
	flexio_status ret = FLEXIO_STATUS_SUCCESS;
	int err;

	if (window == NULL)
		return ret;

	if (window->devx_window != NULL) {
		err = mlx5dv_devx_obj_destroy(window->devx_window);
		if (err) {
			flexio_err("Failed to destroy window object");
			ret = -FLEXIO_STATUS_FAILED;
		}

		window->devx_window = NULL;
		window->process->ref_count.num_of_windows--;
	}

	if (window->alias_pd) {
		err = mlx5dv_devx_obj_destroy(window->alias_pd->devx_obj);
		if (err) {
			flexio_err("Failed to destroy window's alias PD");
			ret = -FLEXIO_STATUS_FAILED;
		}

		free(window->alias_pd);
		window->alias_pd = NULL;
	}

	free(window);

	return ret;
}

flexio_status flexio_outbox_create(struct flexio_process *process, struct ibv_context *other_ctx,
				   struct flexio_uar *uar, struct flexio_outbox **outbox)
{
	struct flexio_prm_outbox_attr attr = {0};

	if (!outbox) {
		flexio_err("illegal outbox argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!process) {
		flexio_err("illegal process argument: NULL\n");
		goto err_out;
	}

	if (!uar) {
		flexio_err("illegal uar argument: NULL\n");
		goto err_out;
	}

	if (!process->hca_caps->has_dpa_outbox_obj) {
		flexio_err("DPA outbox creation is not supported by this device");
		goto err_out;
	}

	if (process->ref_count.num_of_outboxes >= process->caps.max_num_of_outboxes) {
		flexio_err("Max number of outboxes per process reached");
		goto err_out;
	}

	*outbox = calloc(1, sizeof(struct flexio_outbox));
	assert(*outbox);

	if (check_create_alias_uar(process, other_ctx, &uar->aliasable, &(*outbox)->alias_dev_uar,
				   &attr.uar))
		goto err_create_alias;

	attr.process_id = process->process_id;
	(*outbox)->devx_outbox = flexio_create_prm_outbox(process->ibv_ctx, &attr,
							  &(*outbox)->outbox_id);

	if (!(*outbox)->devx_outbox) {
		flexio_err("Failed to create Flex IO outbox");
		goto err_create;
	}

	(*outbox)->process = process;
	(*outbox)->orig_flexio_uar = uar;
	process->ref_count.num_of_outboxes++;

	return FLEXIO_STATUS_SUCCESS;

err_create:
err_create_alias:
	flexio_outbox_destroy(*outbox);
err_out:
	*outbox = NULL;
	return -FLEXIO_STATUS_FAILED;
}

flexio_status flexio_outbox_destroy(struct flexio_outbox *outbox)
{
	flexio_status ret = FLEXIO_STATUS_SUCCESS;
	int err = 0;

	if (!outbox)
		return ret;

	if (outbox->devx_outbox) {
		err = mlx5dv_devx_obj_destroy(outbox->devx_outbox);
		if (err) {
			flexio_err("Failed to destroy outbox object");
			ret = -FLEXIO_STATUS_FAILED;
		}

		outbox->devx_outbox = NULL;
		outbox->process->ref_count.num_of_outboxes--;
	}

	if (outbox->alias_dev_uar) {
		err = mlx5dv_devx_obj_destroy(outbox->alias_dev_uar->devx_obj);
		if (err) {
			flexio_err("Failed to destroy outbox's alias UAR");
			ret = -FLEXIO_STATUS_FAILED;
		}

		free(outbox->alias_dev_uar);
		outbox->alias_dev_uar = NULL;
	}

	free(outbox);

	return ret;
}

flexio_status flexio_uar_create(struct flexio_process *process, struct mlx5dv_devx_uar *devx_uar,
				struct flexio_uar **flexio_uar)
{
	if (!process || !devx_uar) {
		flexio_err("illegal process/devx_uar argument: NULL\n");
		*flexio_uar = NULL;
		return -FLEXIO_STATUS_FAILED;
	}

	*flexio_uar = calloc(1, sizeof(struct flexio_uar));
	assert(*flexio_uar);

	(*flexio_uar)->devx_uar = devx_uar;
	(*flexio_uar)->aliasable.id = devx_uar->page_id;
	(*flexio_uar)->aliasable.type = MLX5_GENERAL_OBJECT_TYPES_UAR;
	(*flexio_uar)->aliasable.is_supported = process->hca_caps->uar_allowed_supported;

	return FLEXIO_STATUS_SUCCESS;
}

flexio_status flexio_uar_destroy(struct flexio_uar *uar)
{
	if (!uar)
		return FLEXIO_STATUS_SUCCESS;

	free(uar);
	return FLEXIO_STATUS_SUCCESS;
}

flexio_uintptr_t qalloc_dbr(struct flexio_process *process)
{
	flexio_uintptr_t dbr_daddr = 0;
	__be32 dbr[2] = { 0, 0 };

	if (flexio_copy_from_host(process, dbr, sizeof(dbr), &dbr_daddr))
		return 0;

	return dbr_daddr;
}

int modify_dbr(struct flexio_process *process, flexio_uintptr_t dbr_daddr, uint32_t rcv_counter,
	       uint32_t send_counter)
{
	__be32 dbr[2];

	dbr[0] = htobe32(rcv_counter & 0xffff);
	dbr[1] = htobe32(send_counter & 0xffff);

	if (flexio_host2dev_memcpy(process, dbr, sizeof(dbr), dbr_daddr))
		return -1;

	return 0;
}
/* Getters */
uint32_t flexio_query_pdn(struct ibv_pd *pd)
{
	struct mlx5dv_pd flexio_pd = {0};
	struct mlx5dv_obj pd_obj;
	int err;

	if (!pd)
		return UINT32_MAX;

	pd_obj.pd.in = pd;
	pd_obj.pd.out = &flexio_pd;

	err = mlx5dv_init_obj(&pd_obj, MLX5DV_OBJ_PD);
	if (err) {
		flexio_err("Failed to init PD object (err=%d)", err);
		return UINT32_MAX;
	}

	return pd_obj.pd.out->pdn;
}

struct mlx5dv_devx_uar *flexio_uar_get_devx_uar(struct flexio_uar *flexio_uar)
{
	return flexio_uar ? flexio_uar->devx_uar : NULL;
}

struct flexio_uar *flexio_outbox_get_uar(struct flexio_outbox *outbox)
{
	return outbox ? outbox->orig_flexio_uar : NULL;
}

uint32_t flexio_outbox_get_id(struct flexio_outbox *outbox)
{
	return outbox ? outbox->outbox_id : UINT32_MAX;
}

uint32_t flexio_window_get_id(struct flexio_window *window)
{
	return window ? window->window_id : UINT32_MAX;
}

struct ibv_pd *flexio_process_get_pd(struct flexio_process *process)
{
	return process ? process->internal_pd : NULL;
}

void flexio_mutex_init(pthread_mutex_t *lock)
{
	pthread_mutexattr_t mattr;
	int rc;

	rc = pthread_mutexattr_init(&mattr);
	assert(!rc);

	rc = pthread_mutexattr_settype(&mattr, PTHREAD_MUTEX_ERRORCHECK_NP);
	assert(!rc);

	rc = pthread_mutex_init(lock, &mattr);
	assert(!rc);
}

uint32_t flexio_process_get_dumem_id(struct flexio_process *process)
{
	return process->dumem.id;
}

uint64_t flexio_process_get_dumem_addr(struct flexio_process *process)
{
	return process->heap_process_umem_base_daddr;
}

uint64_t flexio_process_get_dumem_size(struct flexio_process *process)
{
	return L2V(process->hca_caps->log_max_num_dpa_mem_blocks) *
		process->hca_caps->dpa_mem_block_size;
}

uint32_t flexio_event_handler_get_thread_id(struct flexio_event_handler *event_handler)
{
	return event_handler->thread->aliasable.id;
}
