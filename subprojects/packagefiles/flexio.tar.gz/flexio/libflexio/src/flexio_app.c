/*
 * SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <malloc.h>
#include <libflexio/flexio.h>
#include "flexio_log.h"
#include "flexio_priv.h"
#include "ccan/list/list.h"

static struct list_head g_apps_list;
static uint32_t g_num_apps = 0;

#define SELF_EXE_NAME_MAX_SIZE 1024
static int get_sig_section(const char *sig_sec_name, void **sig_buffer, size_t *sig_size)
{
	char self_exe[SELF_EXE_NAME_MAX_SIZE] = {0};
	uint64_t sec_off, sec_size;
	ssize_t readlink_res;
	size_t self_elf_size;
	void *self_elf_buf;

	readlink_res = readlink("/proc/self/exe", self_exe, SELF_EXE_NAME_MAX_SIZE);
	if (readlink_res == -1 || readlink_res == SELF_EXE_NAME_MAX_SIZE) {
		flexio_err("readlink /proc/sel/exe failed\n");
		return -1;
	}

	if (get_elf_file(self_exe, &self_elf_buf, &self_elf_size)) {
		flexio_err("Get ELF from /proc/sel/exe failed\n");
		return -1;
	}
	/* coverity[tainted_scalar] self_elf_buf */
	if (elf_get_section_val(self_elf_buf, self_elf_size, sig_sec_name, &sec_off, &sec_size))
	{
		flexio_err("Get signature section from self ELF failed\n");
		goto err_get_sec_val;
	}

	assert(posix_memalign(sig_buffer, 64, sec_size) == 0);
	assert(*sig_buffer);
	memcpy(*sig_buffer, (char *)self_elf_buf + sec_off, sec_size);
	*sig_size = sec_size;

	free(self_elf_buf);

	return 0;

err_get_sec_val:
	free(self_elf_buf);

	return -1;
}

#pragma GCC diagnostic ignored "-Wpedantic"
int get_dev_func_data(struct flexio_app *app, flexio_func_t *host_func_addr,
		      struct flexio_func **out_func)
{
	struct flexio_func *func;

	HASH_FIND_INT(app->func_list, &host_func_addr, func);

	if (!func)
		return -1;

	*out_func = func;

	return 0;
}

const char *flexio_app_get_name(struct flexio_app *app)
{
	if (!app) {
		flexio_err("Illegal application argument: NULL\n");
		return NULL;
	}

	return app->app_name;
}

size_t flexio_app_get_elf_size(struct flexio_app *app)
{
	if (!app) {
		flexio_err("Illegal application argument: NULL\n");
		return 0;
	}

	return app->elf_size;
}

flexio_status flexio_app_get_elf(struct flexio_app *app, uint64_t *bin_buff, size_t bin_size)
{
	if (!app) {
		flexio_err("Illegal application argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!bin_buff) {
		flexio_err("Illegal binary buffer argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (bin_size < app->elf_size) {
		flexio_err("bin size %zu smaller than app elf size %zu\n",
			   bin_size, app->elf_size);
		return -FLEXIO_STATUS_FAILED;
	}

	memcpy(bin_buff, app->elf_buffer, app->elf_size);

	return FLEXIO_STATUS_SUCCESS;
}


flexio_status flexio_app_create(struct flexio_app_attr *fattr, struct flexio_app **out_app)
{
	size_t app_name_len, sig_sec_name_len;
	struct flexio_app *app;

	if (!fattr) {
		flexio_err("Illegal fattr argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!out_app) {
		flexio_err("Illegal out_app argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	*out_app = NULL;

	if (!fattr->app_name || !fattr->app_ptr) {
		flexio_err("Illegal app name/ptr: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!fattr->app_sig_sec_name) {
		flexio_err("Illegal app sig section name ptr: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (fattr->app_bsize == 0) {
		flexio_err("Illegal app size: 0\n");
		return -FLEXIO_STATUS_FAILED;
	}

	app_name_len = strnlen(fattr->app_name, FLEXIO_MAX_NAME_LEN + 1);
	if (app_name_len > FLEXIO_MAX_NAME_LEN) {
		flexio_err("Application name is too long, max length is %u\n",
			   FLEXIO_MAX_NAME_LEN);
		return -FLEXIO_STATUS_FAILED;
	}

	sig_sec_name_len = strnlen(fattr->app_sig_sec_name, FLEXIO_MAX_NAME_LEN + 1);
	if (sig_sec_name_len > FLEXIO_MAX_NAME_LEN) {
		flexio_err("Sig section name is too long, max length is %u\n",
			   FLEXIO_MAX_NAME_LEN);
		return -FLEXIO_STATUS_FAILED;
	}

	app = calloc(1, sizeof(*app));
	assert(app);

	strncpy(app->app_name, fattr->app_name, FLEXIO_MAX_NAME_LEN);

	app->elf_size = fattr->app_bsize;
	assert(posix_memalign(&app->elf_buffer, 64, app->elf_size) == 0);
	assert(app->elf_buffer);
	memcpy(app->elf_buffer, fattr->app_ptr, app->elf_size);

	/* Signature stuff */
	if (sig_sec_name_len == 0) {
		app->sig_exist = 0;
	} else {
		if (get_sig_section(fattr->app_sig_sec_name, &app->sig_buffer, &app->sig_size)) {
			flexio_err("Get signature section %s failed\n", fattr->app_sig_sec_name);
			goto err_get_sig_sec;
		}
		app->sig_exist = 1;
	}

	*out_app = app;

	if (!g_num_apps)
		list_head_init(&g_apps_list);
	g_num_apps++;
	list_node_init(&app->node);
	list_add(&g_apps_list, &app->node);

	return FLEXIO_STATUS_SUCCESS;

err_get_sig_sec:
	free(app->elf_buffer);
	free(app);

	return -FLEXIO_STATUS_FAILED;
}

flexio_status flexio_app_destroy(struct flexio_app *app)
{
	struct flexio_func *current_func;
	struct flexio_func *tmp;

	if (!app)
		return FLEXIO_STATUS_SUCCESS;

	HASH_ITER(hh, app->func_list, current_func, tmp) {
		/* coverity[var_deref_op] */
		HASH_DEL(app->func_list, current_func);
		free(current_func);
	}

	list_del(&app->node);
	g_num_apps -= 1;

	free(app->elf_buffer);
	free(app->sig_buffer);

	free(app);

	return FLEXIO_STATUS_SUCCESS;
}

flexio_status flexio_func_pup_register(struct flexio_app *app,
				       const char *dev_func_name, const char *dev_unpack_func_name,
				       flexio_func_t *host_stub_func_addr, size_t argbuf_size,
				       flexio_func_arg_pack_fn_t *host_pack_func)
{
	flexio_uintptr_t dev_func_addr, dev_unpack_func_addr;
	size_t dev_func_name_len, dev_unpack_func_name_len;
	struct flexio_func *func;

	if (!app) {
		flexio_err("Illegal application argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!dev_func_name || !dev_unpack_func_name) {
		flexio_err("Illegal dev func name argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	HASH_FIND_INT(app->func_list, &host_stub_func_addr, func);
	if (func) {
		flexio_err("Function with host_stub_func_addr %p is already registered\n",
			   (void *)host_stub_func_addr);
		return -FLEXIO_STATUS_FAILED;
	}

	dev_func_name_len = strnlen(dev_func_name, FLEXIO_MAX_NAME_LEN + 1);
	if (dev_func_name_len > FLEXIO_MAX_NAME_LEN) {
		flexio_err("Device function name is too long, max length is %u\n",
			   FLEXIO_MAX_NAME_LEN);
		return -FLEXIO_STATUS_FAILED;
	}
	if (elf_get_sym_val(app->elf_buffer, app->elf_size, dev_func_name, &dev_func_addr)) {
		flexio_err("Failed to find device function %s in app ELF)\n", dev_func_name);
		return -FLEXIO_STATUS_FAILED;
	}

	dev_unpack_func_name_len = strnlen(dev_unpack_func_name, FLEXIO_MAX_NAME_LEN + 1);
	if (dev_unpack_func_name_len > FLEXIO_MAX_NAME_LEN) {
		flexio_err("Device unpack function name is too long, max length is %u\n",
			   FLEXIO_MAX_NAME_LEN);
		return -FLEXIO_STATUS_FAILED;
	}
	if (elf_get_sym_val(app->elf_buffer, app->elf_size, dev_unpack_func_name,
			    &dev_unpack_func_addr))
	{
		flexio_err("Failed to find device function %s in app ELF)\n", dev_unpack_func_name);
		return -FLEXIO_STATUS_FAILED;
	}

	func = calloc(1, sizeof(*func));
	assert(func);

	strncpy(func->dev_func_name, dev_func_name, FLEXIO_MAX_NAME_LEN);
	func->dev_func_addr = dev_func_addr;
	strncpy(func->dev_unpack_func_name, dev_unpack_func_name, FLEXIO_MAX_NAME_LEN);
	func->dev_unpack_func_addr = dev_unpack_func_addr;

	func->host_stub_func_addr = host_stub_func_addr;
	func->argbuf_size = argbuf_size;
	func->arg_pack_fn = host_pack_func;
	func->app = app;
	func->pup = 1;

	HASH_ADD_INT(app->func_list, host_stub_func_addr, func);

	/* coverity[leaked_storage] */
	return FLEXIO_STATUS_SUCCESS;
}

flexio_status flexio_func_register(struct flexio_app *app,
				   const char *dev_func_name,
				   flexio_func_t **out_func)
{
	flexio_func_t *host_stub_func_addr_sub;
	flexio_uintptr_t dev_func_addr;
	size_t dev_func_name_len;
	struct flexio_func *func;

	if (!out_func) {
		flexio_err("Illegal out_func argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	*out_func = NULL;

	if (!app) {
		flexio_err("Illegal application argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!dev_func_name) {
		flexio_err("Illegal dev func name argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	dev_func_name_len = strnlen(dev_func_name, FLEXIO_MAX_NAME_LEN + 1);
	if (dev_func_name_len > FLEXIO_MAX_NAME_LEN) {
		flexio_err("Device function name is too long, max length is %u\n",
			   FLEXIO_MAX_NAME_LEN);
		return -FLEXIO_STATUS_FAILED;
	}
	if (elf_get_sym_val(app->elf_buffer, app->elf_size, dev_func_name, &dev_func_addr)) {
		flexio_err("Failed to find device function %s in app ELF)\n", dev_func_name);
		return -FLEXIO_STATUS_FAILED;
	}

	func = calloc(1, sizeof(*func));
	assert(func);

	strncpy(func->dev_func_name, dev_func_name, FLEXIO_MAX_NAME_LEN);
	func->dev_func_addr = dev_func_addr;

	host_stub_func_addr_sub = (flexio_func_t *)func;
	func->host_stub_func_addr = host_stub_func_addr_sub;
	func->app = app;
	func->pup = 0;

	HASH_ADD_INT(app->func_list, host_stub_func_addr, func);

	*out_func = host_stub_func_addr_sub;

	return FLEXIO_STATUS_SUCCESS;
}

flexio_status flexio_func_get_register_info(struct flexio_app *app,
					    flexio_func_t *host_stub_func_addr, uint32_t *pup,
					    char *dev_func_name, char *dev_unpack_func_name,
					    size_t func_name_size, size_t *argbuf_size,
					    flexio_func_arg_pack_fn_t **host_pack_func,
					    flexio_uintptr_t *dev_func_addr,
					    flexio_uintptr_t *dev_unpack_func_addr)
{
	struct flexio_func *func;

	if (!app) {
		flexio_err("Illegal application argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!dev_func_name) {
		flexio_err("Illegal dev func name argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!dev_func_addr) {
		flexio_err("Illegal dev_func_addr argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!pup) {
		flexio_err("Illegal pup argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	if (!func_name_size) {
		flexio_err("Illegal func_name_size argument: 0\n");
		return -FLEXIO_STATUS_FAILED;
	}

	HASH_FIND_INT(app->func_list, &host_stub_func_addr, func);
	if (!func) {
		flexio_err("No function with host_stub_func_addr %p is registered\n",
			   (void *)host_stub_func_addr);
		return -FLEXIO_STATUS_FAILED;
	}

	*pup = func->pup;
	strncpy(dev_func_name, func->dev_func_name, func_name_size);
	dev_func_name[func_name_size - 1] = '\0';
	*dev_func_addr = func->dev_func_addr;

	if (func->pup) {
		if (!dev_unpack_func_name || !dev_unpack_func_addr) {
			flexio_err("Illegal dev unpack func name or addr argument: NULL\n");
			return -FLEXIO_STATUS_FAILED;
		}
		if (!host_pack_func) {
			flexio_err("Illegal host pack func argument: NULL\n");
			return -FLEXIO_STATUS_FAILED;
		}
		if (!argbuf_size) {
			flexio_err("Illegal argbuf size argument: NULL\n");
			return -FLEXIO_STATUS_FAILED;
		}
		strncpy(dev_unpack_func_name, func->dev_unpack_func_name, func_name_size);
		dev_unpack_func_name[func_name_size - 1] = '\0';
		*argbuf_size = func->argbuf_size;
		*host_pack_func = func->arg_pack_fn;
		*dev_unpack_func_addr = func->dev_unpack_func_addr;
	}

	return FLEXIO_STATUS_SUCCESS;
}

flexio_status flexio_app_get_list(struct flexio_app ***out_app_list, uint32_t *out_num_apps)
{
	struct flexio_app *app, **app_out;

	if (!out_app_list) {
		flexio_err("Illegal out_app_list argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	*out_app_list = NULL;

	if (!out_num_apps) {
		flexio_err("Illegal out_num_apps argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	*out_app_list = calloc(g_num_apps, sizeof(app));
	assert(*out_app_list);

	app_out = *out_app_list;
	list_for_each(&g_apps_list, app, node) {
		*app_out = app;
		app_out++;
	}

	*out_num_apps = g_num_apps;

	return FLEXIO_STATUS_SUCCESS;
}

flexio_status flexio_app_list_free(struct flexio_app **apps_list)
{
	if (!apps_list) {
		flexio_err("Illegal application list argument: NULL\n");
		return -FLEXIO_STATUS_FAILED;
	}

	free(apps_list);

	return FLEXIO_STATUS_SUCCESS;
}
